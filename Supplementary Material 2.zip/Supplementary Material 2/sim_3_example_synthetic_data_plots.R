# Plot Figures S9 and S10

# Set working directory

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

########################################################################################################

# Load required packages (install if not installed already)

load.lib     <- c("MASS","tidyverse", "patchwork", "plyr","ggplot2", "blorr",
                  "DescTools", "ggpubr", "plotly", "GGally",  "plyr",
                  "scales", "RColorBrewer", "openxlsx")

# Then we select only the packages that aren't currently installed.

install.lib <- load.lib[!load.lib %in% installed.packages()]

# And finally we install the missing packages, including their dependency.

for (lib in install.lib) install.packages(lib,dependencies=TRUE)

# After the installation process completes, we load all packages.

sapply(load.lib,require,character=TRUE)

########################################################################################################


# Load data

load("intermediate_results/example_synthetic.Rdata")

##################################################################################


scale_fill_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'fill',
    values = setNames(hue_pal()(10)[c(1,5,7,6)], levels(res$method)), drop=TRUE, limits=force,
    ...
  )
}

scale_col_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'col',
    values = setNames(hue_pal()(10)[c(1,5,7,6)], levels(res$method)), drop=TRUE, limits=force,
    ...
  )
}

###################################################################################

# Figure S9

res$prob_cs  <- ifelse(res$cs>=0.9 & res$cs<=1.1,1,0)

res$method = factor(res$method)
levels(res$method) = c("MLE","Ridge", "Boot-Ridge", "Mod-Ridge")

res <- res%>%filter(method!="Boot-Ridge")


lam.ridge <- ggplot(res%>%filter(method=="Ridge" | method=="Mod-Ridge") ,
                    aes(x=factor(N), y=lambda, fill=method)) +
  geom_boxplot()  + ylab("Tuning parameter (log-scale)")+ xlab("Sample Size")+
  theme_bw()+
  labs(fill="method") +
  scale_y_continuous(limits=c(0.003, 0.2), trans="log10")  +
  theme(legend.position="bottom") +
  labs(shape="Method", fill="Method") + scale_fill_shrinkage()


cs <- ggplot(res%>%filter(method=="MLE" | method=="Ridge" | method=="Mod-Ridge") ,
             aes(x=factor(N),y=cs, fill=method)) +
  geom_boxplot()  + ylab("Calibration slope (log-scale)")+ xlab("Sample Size")+
  theme_bw()+
  geom_hline(yintercept = 1,linetype="dashed") +
  geom_hline(yintercept = 0.9,linetype="dashed") +
  labs(fill="method")+
  theme(legend.position="bottom") +
  scale_y_continuous(limits=c(0.5, 2),breaks=c(0, 0.5, 0.8, 0.9, 1, 1.1, 1.5, 2.5), trans="log10") +
  labs(shape="Method", fill="Method") + scale_fill_shrinkage()

septable <- ddply(res, c("N","method"),
                  summarise, value = mean(sep,na.rm=TRUE))


cstat <- ggplot(res%>%filter(method=="MLE" | method=="Ridge" | method=="Mod-Ridge") ,
                aes(x=factor(N),y=cstat, fill=method)) +
  geom_boxplot()  + ylab("Estimated C-statistic")+ xlab("Sample Size")+
  theme_bw()+
  labs(fill="method") +
  scale_y_continuous(limits=c(0.66, 0.75)) +
  theme(legend.position="bottom") +
  labs(shape="Method", fill="Method")+scale_fill_shrinkage()


brier <- ggplot(res%>%filter(method=="MLE" | method=="Ridge" | method=="Mod-Ridge") ,
                aes(x=factor(N),y=sqrt(brier), fill=method)) +
  geom_boxplot()  + ylab("Estimated Brier Score")+ xlab("Sample Size")+
  theme_bw()+
  labs(fill="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", fill="Method") + scale_fill_shrinkage()


res$logerror <- sqrt((log(1)-log(res[,3]))^2)
res$error    <- sqrt((1-res[,3])^2)


logerror <- ddply(res, c("N","method"),
                  summarise, value = mean(logerror,na.rm=TRUE))

error <- ddply(res, c("N","method"),
               summarise, value = mean(error,na.rm=TRUE))


log_rmsd_plot <- ggplot(logerror,
                        aes(x=N, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("RMSD log(Calibration Slope)")+ xlab("Sample size") +
  geom_hline(yintercept = logerror$value[4], linetype="dashed",size=1)+
  theme_bw() +
  scale_x_continuous(breaks=logerror$N)   +
  scale_y_continuous(limits=c(0.07, 0.18)) +
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method") + scale_col_shrinkage()


prob_cs <-ddply(res, c("N","method"),
                summarise, value = mean(prob_cs,na.rm=TRUE))

prob_plot <- ggplot(prob_cs,
                    aes(x=N, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("Probability well calibrated")+ xlab("Sample size") +
  geom_hline(yintercept = prob_cs$value[4], linetype="dashed",size=1)+
  theme_bw() +
  scale_x_continuous(breaks=logerror$N)   +
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method") +scale_col_shrinkage()


synthetic_example <- ggarrange(lam.ridge, cs , log_rmsd_plot, prob_plot,
                               labels = c("        A", "      B", "       C", "      D"),
                               ncol = 2, nrow = 2)

synthetic_example <- annotate_figure(synthetic_example,
                                     top = text_grob(paste("Synthetic data application based on the Heart Valve Surgery data"),
                                                     color = "black", face = "bold", size = 13))

figure_S9 <- synthetic_example
figure_S9


ggsave("figures_tables/figure_S9.pdf", width=9, height=7)
ggsave("figures_tables/figure_S9.tiff", width=9, height=7)


########################################################################################################

# Figure S10

synthetic_example_cbrier <- ggarrange(cstat, brier,
                                      #labels = c("        A", "        B"),
                                      ncol = 2, nrow = 1)

synthetic_example_cbrier <- annotate_figure(synthetic_example_cbrier,
                                            top = text_grob(paste("Synthetic data application based on the Heart Valve Surgery data \n C-Statistic and Brier Score"),
                                                            color = "black", face = "bold", size = 13))

figure_S10 <- synthetic_example_cbrier
figure_S10

ggsave("figures_tables/figure_S10.pdf", width=9, height=5)
ggsave("figures_tables/figure_S10.tiff", width=9, height=5)

