
`%dopar%` <- foreach::`%dopar%`
`%do%` <- foreach::`%do%`

#Parallel processing
all_methods <- foreach(i=1:nsim, .combine='rbind', .packages=c('foreach','MASS','RcppNumerical', 'pROC', 'brglm2', 'logistf', 'detectseparation','RcppNumerical', 'glmnet')) %dopar% {

  # cat(paste("\n","Starting iteration",i,"\n"),
  #     file="log.txt", append=TRUE)


     set.seed(i+1000)

  # Validation data
    DATA.VAL <- generate_data(NN = Nval, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors,beta.0 = inputs$beta.0[k] , strength=strength, cor0=0.1, cor1=0.05)

  # Training data
    DATA <- generate_data(NN = N[j], n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors, beta.0 = inputs$beta.0[k], strength=strength, cor0=0.1, cor1=0.05)

  # Training
    x          = as.matrix(DATA[,1:(n.true.predictors+n.noise.predictors)])
    y          = DATA$y


  # Validation
    xval          = as.matrix(DATA.VAL[,1:(n.true.predictors+n.noise.predictors)])
    yval          = DATA.VAL$y

  #Check for separation
    sep <- ifelse(glm(y~x, family="binomial", method = "detect_separation", purpose="test",
                      linear_program = "dual")$outcome==T, 1, 0)

    # MLE
    fit  <-  withwarnings(glm(y ~ ., data = DATA, family = 'binomial'))

    if (length(fit$value)!=0) {

    fit     <- fit$value
    beta    <- coef(fit)
    betain  <- beta
    mle <-  c(prev, strength, ctrue[k], epv[j], 0, NA, measures(yval, xval, beta, beta.true), sep )

    # Bootstrap Shrinkage

    DATA2           <-  DATA
    DATA2           <-  cbind(1, DATA)
    datasf          <- cbind(y,x)
    sf              <- bootsf(datasf,100);sf

    beta            <- c(1,rep(sf,n.predictors))*betain
    off             <- glm(y~1,offset=as.vector(cbind(1,x)%*%beta),family=binomial)
    beta[1]         <- beta[1]+coef(off)
    lambda          <- sf
    boot.shrink <- c(prev, strength, ctrue[k], epv[j], 2, lambda, measures(yval, xval, beta, beta.true), sep)


    #Heuristic shrinkage (removed)
    heur.shrink    <-  c(prev, strength, ctrue[k], epv[j], 3, NA, rep(NA,5))

    # Cross-validation folds for modified and bootstrap tuning
    nfolds <- 10

    # Ridge
    set.seed(i)
    fit   <-  cv.glmnet(x=x, y=y,  alpha = 0, family = 'binomial',  nfolds = nfolds, type.measure = 'deviance',parallel=TRUE)
    beta  <-  as.vector(coef(fit,s="lambda.min")); lambda  <-  fit$lambda.min
    ridge <-  c(prev, strength, ctrue[k], epv[j], 4, lambda, measures(yval, xval, beta, beta.true), sep )


    # Mod-Ridge
    set.seed(i)
    # if (strength==0.93) {
    a               <-  mod_penal_ave_foreach(x=x, y=y, method="ridge", bn=bn, nfolds=nfolds, boot=TRUE)
    lambda          <-  a$lambda.boot
    beta            <-  a$beta.boot
    boot.ridge      <-  c(prev, strength, ctrue[k], epv[j], 5, lambda, measures(yval, xval, beta, beta.true), sep)
    # } else
    # boot.ridge      <- c(prev, strength, ctrue[k], epv[j], 5, NA, rep(NA,5))


    # Bootstrap Ridge
    set.seed(i)

    a   <-  boot_penal_foreach(x=x, y=y, method="ridge", bn=bn)
    lambda          <-  a$lambda.boot
    beta            <-  a$beta.boot
    boot.ridge1 <-  c(prev, strength, ctrue[k], epv[j], 6, lambda, measures(yval, xval, beta, beta.true), sep)

    # Lasso

    set.seed(i)
    fit  <-  cv.glmnet(x=x, y=y,  alpha = 1, family = 'binomial',  nfolds = nfolds, type.measure = 'deviance', parallel=TRUE)
    beta <- as.vector(coef(fit,s="lambda.min"));lambda <- fit$lambda.min
    lasso <-  c(prev, strength, ctrue[k], epv[j], 7, lambda, measures(yval, xval, beta, beta.true), sep)
    # Mod-Lasso

    set.seed(i)

    # if (strength==0.93) {
    a  <-  mod_penal_ave_foreach(x=x, y=y, method="lasso", bn=bn, nfolds=nfolds, boot=TRUE)
    lambda          <-  a$lambda.boot
    beta            <-  a$beta.boot
    boot.lasso      <-  c(prev, strength, ctrue[k], epv[j], 8, lambda, measures(yval, xval, beta, beta.true), sep)
    # } else
    # boot.lasso      <-  c(prev, strength, ctrue[k], epv[j], 8, NA, rep(NA,5))

    # Bootstrap lasso

    set.seed(i)

    a  <-  boot_penal_foreach(x=x, y=y, method="lasso", bn=bn)
    lambda          <-  a$lambda.boot
    beta            <-  a$beta.boot
    boot.lasso1 <-  c(prev, strength, ctrue[k], epv[j], 9, lambda, measures(yval, xval, beta, beta.true), sep)

    } else  {

      mle            <-  c(prev, strength, ctrue[k], epv[j], 0, NA, rep(NA,5))
      firth          <-  c(prev, strength, ctrue[k], epv[j], 1, NA, rep(NA,5))
      boot.shrink    <-  c(prev, strength, ctrue[k], epv[j], 2, NA, rep(NA,5))
      heur.shrink    <-  c(prev, strength, ctrue[k], epv[j], 3, NA, rep(NA,5))
      ridge          <-  c(prev, strength, ctrue[k], epv[j], 4, NA, rep(NA,5))
      boot.ridge     <-  c(prev, strength, ctrue[k], epv[j], 5, NA, rep(NA,5))
      boot.ridge1    <-  c(prev, strength, ctrue[k], epv[j], 6, NA, rep(NA,5))
      lasso          <-  c(prev, strength, ctrue[k], epv[j], 7, NA, rep(NA,5))
      boot.lasso     <-  c(prev, strength, ctrue[k], epv[j], 8, NA, rep(NA,5))
      boot.lasso1    <-  c(prev, strength, ctrue[k], epv[j], 9, NA, rep(NA,5))

    }

    rbind(mle, boot.shrink, heur.shrink, ridge, boot.ridge, boot.ridge1, lasso, boot.lasso, boot.lasso1)
}


# Run Firth separately
last_method <- foreach(i=1:nsim, .combine='rbind', .packages=c('MASS','RcppNumerical', 'pROC', 'brglm2', 'logistf', 'detectseparation','RcppNumerical', 'glmnet')) %do% {

  set.seed(i+1000)
  DATA.VAL <- generate_data(NN = Nval, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors,beta.0 = inputs$beta.0[k] , strength=strength, cor0=0.1, cor1=0.05)

  DATA <- generate_data(NN = N[j], n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors, beta.0 = inputs$beta.0[k], strength=strength, cor0=0.1, cor1=0.05)

  # Development

  x          = as.matrix(DATA[,1:(n.true.predictors+n.noise.predictors)])
  y          = DATA$y


  # Validation
  xval          = as.matrix(DATA.VAL[,1:(n.true.predictors+n.noise.predictors)])
  yval          = DATA.VAL$y

  # Firth
  fit        <-  flic(y~x)
  beta       <-  as.vector(coefficients(fit))
  firth      <-  c(prev, strength, ctrue[k], epv[j], 1, NA, measures(yval, xval, beta, beta.true), 0 )
  firth
}

all_methods <- rbind(all_methods,last_method)


