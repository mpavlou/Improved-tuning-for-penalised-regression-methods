# Make sure path is ok

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

###########################################################################################
# Code to produce (ans save to folder 'figures_tables')

# Figures 1, 2

#########################################

# Install required libraries if needed

load.lib <-c("MASS","tidyverse", "patchwork", "plyr","ggplot2", "blorr",
             "DescTools", "ggpubr", "plotly", "GGally",  "plyr","scales", "RColorBrewer")

# Then we select only the packages that aren't currently installed.

install.lib <- load.lib[!load.lib %in% installed.packages()]

# And finally we install the missing packages, including their dependency.
for (lib in install.lib) install.packages(lib,dependencies=TRUE)

# After the installation process completes, we load all packages.
sapply(load.lib,require,character=TRUE)

###########################################################################################


# Load data

load("intermediate_results/penalised_p05_kfold_10F.Rdata")


out_p$size = factor(out_p$epv)
levels(out_p$size) = c("N/2", "3N/4", "N", "5N/4")

##################################################################################################################################

out_p$method = factor(out_p$method)
levels(out_p$method) = c("MLE", "Ridge 5F", "Ridge 10F", "Ridge 20F", "Ridge n-F", "Mod-Ridge", "Boot-Ridge",
                         "Lasso 5F", "Lasso 10F", "Lasso 20F", "Lasso n-F", "Mod-Lasso", "Boot-Lasso")

ridge <- sort(hue_pal()(10)[2:7], decreasing=TRUE)
ridge<- c(ridge[c(1,5,2,3,4,6)])
# show_col(ridge)

lasso <- sort(hue_pal()(13)[9:14])
lasso <- c(lasso,hue_pal()(10)[10])
lasso[5] <- "#E76BF3"
# lasso[3] <-lasso[6]
lasso[4] <- "#FFADFF"
lasso[1] <- "#AC88FF"
 # show_col(lasso)
#
col <-c(hue_pal()(10)[1], ridge, lasso)
# show_col(col)

scale_fill_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'fill',
    values = setNames(col, levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}

scale_col_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'col',
    values = setNames(col, levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}


out_p$ms = factor(out_p$c_true)

low    <- paste("C=",round(inputs$c_true[1],2));
high   <- paste("C=",round(inputs$c_true[2],2));

out_p$ms<- low
out_p$ms[out_p$strength==inputs$strength[2]]<-high
out_p$ms <- factor(out_p$ms, levels=c(low, high))

options(warn=-1)

##################################################################################################################################

# Figures 1 and 2

k<-1

toplot <-out_p%>% filter(ms==low)
toplot$slope[toplot$slope<0] <- 0.1
toplot$slope[toplot$slope>10] <- 10

toplot <- toplot %>% drop_na(epv)

N <- unique(toplot$epv)*n.predictors/prev
N <- round(N/10)*10


lam.ridge <- ggplot(toplot%>%filter(method=="Ridge 5F" | method=="Ridge 10F" | method=="Ridge 20F" | method=="Ridge n-F" |  method=="Mod-Ridge"|  method=="Boot-Ridge") , aes(x=size, y=lambda, fill=method)) +
  geom_boxplot()  + ylab("Tuning parameter - Ridge (log-scale)")+ xlab("Sample Size") +
  theme_bw() +
  labs(fill="method") +
  theme(legend.position="bottom") +
  labs(shape="Method", fill="Method") +
  guides(fill=guide_legend(nrow=2,byrow=TRUE)) + scale_fill_shrinkage() +
  scale_y_continuous(limits = c(0.01, 0.24),trans="log10") +
  ggplot2::theme(text =  ggplot2::element_text(size = 18))


lam.lasso <- ggplot(toplot%>%filter(method=="Lasso 5F" | method=="Lasso 10F" | method=="Lasso 20F" | method=="Lasso n-F" | method=="Mod-Lasso"  | method=="Boot-Lasso"),
                    aes(x=size, y=lambda, fill=method)) +
  geom_boxplot()  + ylab("Tuning parameter - Lasso (log-scale)")+ xlab("Sample Size")+
  theme_bw() +
  theme(legend.position="bottom") +
  labs(fill="method")+labs(shape="Method", fill="Method") +
  scale_y_continuous(limits = c(0.001, 0.04),trans="log10")+
  guides(fill=guide_legend(nrow=2,byrow=TRUE)) +
  ggplot2::theme(text =  ggplot2::element_text(size = 18)) + scale_fill_shrinkage()


lambda <- ggarrange(lam.ridge, lam.lasso,
                   #labels = c("        A", "        B"),
                   ncol = 2, nrow = 1)

lambda_low <-annotate_figure(lambda,
                         top = text_grob(paste("Tuning parameter (Different numbers of cross-validation folds) \nPrevalence = ",
                                         toplot$prev[1], ", C-statistic = ",toplot$c_true[1], ", N = ",N[1]*2,sep=""),
                                         color = "black", face = "bold", size = 16),
)

figure_1 <- lambda_low
figure_1

ggsave("figures_tables/figure_1.pdf", width = 14, height=7)
ggsave("figures_tables/figure_1.tiff", width = 14, height=7)


# Calibration slope k-F

cs_plot_low_ridge <- ggplot(toplot%>%filter(method=="MLE"| method=="Ridge 5F" | method=="Ridge 10F" | method=="Ridge 20F" | method=="Ridge n-F" |  method=="Mod-Ridge"  |  method=="Boot-Ridge"),
  aes(x=size, y=slope, fill=method)) +
  geom_hline(yintercept=1,linetype="dashed") +
  geom_boxplot() + ylab("Calibration Slope (log-scale)")+ xlab("Sample size") +
  theme_bw()+
  labs(fill="method") + labs(shape="Method", fill="Method") +
  theme(legend.position="bottom")+
  scale_y_continuous(breaks=c(0,0.5,0.8, 0.9,1,1.1,1.5,2.5), limits = c(0.5, 2.5),trans="log10") +
  guides(fill=guide_legend(nrow=2,byrow=TRUE)) +
  ggplot2::theme(text =  ggplot2::element_text(size = 18)) + scale_fill_shrinkage()


cs_plot_low_lasso <- ggplot(toplot%>%filter(method=="Lasso 5F" | method=="Lasso 10F" | method=="Lasso 20F" | method=="Lasso n-F" |  method=="Mod-Lasso" |  method=="Boot-Lasso"),
                            aes(x=size, y=slope, fill=method)) +
  geom_hline(yintercept=c(0.9,1),linetype="dashed") +
  geom_boxplot() + ylab("Calibration Slope (log-scale)")+ xlab("Sample Size")+
  theme_bw()+
  labs(fill="method")+labs(shape="Method", fill="Method") +
  theme(legend.position="bottom")+
  scale_y_continuous(breaks=c(0,0.5,0.8,0.9, 1,1.1, 1.5,2.5), limits = c(0.5, 2.5), trans="log10") +
  guides(fill=guide_legend(nrow=2,byrow=TRUE)) +
  ggplot2::theme(text =  ggplot2::element_text(size = 18)) + scale_fill_shrinkage()



cs     <- ggarrange(cs_plot_low_ridge, cs_plot_low_lasso, ncol = 2, nrow = 1)

cs_low <- annotate_figure(cs, top = text_grob(paste("Estimated calibration slope (Different numbers of cross-validation folds) \nPrevalence = ",
                                             toplot$prev[1], ", C-statistic = ",toplot$c_true[1], ", N = ",N[1]*2,sep=""),
                                             color = "black", face = "bold", size = 16))

figure_2 <- cs_low
figure_2

ggsave("figures_tables/figure_2.pdf", width=15, height=7)
ggsave("figures_tables/figure_2.tiff", width=15, height=7)


##################################################################################################################################

