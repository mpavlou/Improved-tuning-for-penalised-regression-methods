# Last edited by Menelaos Pavlou
# 12/04/2024

############################################################################################################

# Modified tuning (mean deviance)

#'  mod_penal_ave_foreach

#' @param x        a matrix, the design matrix
#' @param y        a vector, the binary response variable
#' @param bn       a scalar, the number of bootstrap iterations
#' @param  method  a string, values "ridge" or "lasso"Numeric where to trim (proportion)
#' @param nfolds   a scalar, the number of crossvalidation folds
#' @param parallel a logical, TRUE for parallel computing
#' @param boot     a logical, TRUE means sample with replacement


mod_penal_ave_foreach <- function(x, y, bn=50, method="ridge", f = nfolds/(nfolds-1)-1, 
                                  parallel=TRUE, nfolds=10, boot=TRUE){
  
  if (method=="lasso") a=1
  if (method=="ridge") a=0
  
  pred        <- NULL ; beta.boot   <- NULL
  lambda.boot <- NULL ; cv.boot     <- NULL
  yval        <- y
  xval        <- x
  npred       <- ncol(x)
  data        <- cbind(x,y)
  
  fit <- glmnet(x, y, type.measure = "deviance", family = "binomial", alpha = a, standardize = TRUE, parallel = T)
  
  lambdaseq <- fit$lambda
  lambdaseq <- unique(c(lambdaseq, seq( lambdaseq[length(lambdaseq)], lambdaseq[length(lambdaseq)]/20,
                                        -lambdaseq[length(lambdaseq)]/20 )))
  
  cvd <- NULL
  
  cv.boot <- foreach(i=1:bn, .combine='rbind', .packages=c('MASS','RcppNumerical', 'pROC', 'brglm2', 'detectseparation',
                                                           'RcppNumerical', 'logistf', 'glmnet')) %dopar% {
    
  withwarnings <- function(expr) {
  
  val        <- NULL
  myWarnings <- NULL
  wHandler   <- function(w) {
    myWarnings <<- c(myWarnings, w$message)
    invokeRestart("muffleWarning")
  }
  
  myError  <- NULL
  eHandler <- function(e) {
    myError <<- e$message
    NULL
  }
  val <- tryCatch(withCallingHandlers(expr, warning = wHandler), error = eHandler)
  list(value = val, warnings = myWarnings, error=myError)
}
                                                             
    bs     <- sample(nrow(data), replace=T)
    databs <- data[bs,]
    
    if (boot==FALSE) databs<-data
    
    if (f==0) databs  <- data else
    {
      bs2     <- sample(nrow(data)*f, replace=T)
      databs2 <- data[bs2,]
      databs  <- rbind(databs,databs2)
    }
    
    xbs   <- databs[,1:npred]
    ybs   <- databs[,npred+1]
    
    fitbs <- withwarnings(cv.glmnet(xbs, ybs, type.measure = "deviance", family = "binomial", alpha = a, nfolds = nfolds,
                                    standardize = TRUE, parallel = parallel, lambda = lambdaseq))
    
    
    if ( length(fitbs$error) == 0 ) {
      fitbs  <- fitbs$value
      cvd    <- fitbs$cvm
      
    } else
      
    {
      cvd <- cvd
    }
    
    rbind(cvd)
    
  }
  
  b <- cbind(lambdaseq, colMeans(cv.boot, na.rm = TRUE))
  
  b[order(b[,2]),]
  
  lambda.boot <- b[order(b[,2]),] [1,1]
  
  fit <- glmnet(x, y, type.measure = "deviance", family = "binomial", alpha = a, standardize = TRUE,
                parallel = T, lambda = lambdaseq)
  
  beta.boot   <- as.vector(coef(fit, s = lambda.boot) )
  
  return(list("beta.boot" = beta.boot, "lambda.boot" = lambda.boot))
}

############################################################################################################

# Bootstrap tuning (selection of the tuning parameter that minimizes the averaged
# bootstrap Log-likelihood/Deviance over the bootstrap samples (parallelized)

#'boot_penal_foreach
#'
#' @param x        a matrix, the design matrix
#' @param y        a vector, the binary response variable
#' @param bn       a scalar, the number of bootstrap iterations
#' @param  method  a string, takes values "ridge" or "lasso"
#' @param parallel a logical, TRUE for parallel computing
#' @param  lambda  a vector, provided sequence for the tuning parameter



boot_penal_foreach<-function(x, y, bn = 50, method="ridge", lambda = NULL, parallel = TRUE ){
  
  
  if (method=="lasso") a=1
  if (method=="ridge") a=0
  
  fit       <- glmnet(x,y,type.measure="deviance",family="binomial", alpha=a, standardize=TRUE, parallel=T)
  
  lambdaseq <- fit$lambda
  lambdaseq <- unique(c(lambdaseq, seq( lambdaseq[length(lambdaseq)], lambdaseq[length(lambdaseq)]/20,
                                        -lambdaseq[length(lambdaseq)]/20 )))
  
  pred           <- NULL
  cv.boot        <- NULL
  lambda.min     <- NULL
  beta.boot      <- NULL; lambda.boot   <- NULL
  loglik         <- NULL; loglik_all    <- NULL
  deviance       <- NULL; deviance_all  <- NULL


  yval           <- y
  xval           <- x
  npred          <- ncol(x)
  data           <- cbind(x,y)

  cvboot <- foreach(j = 1:(bn+1), .combine='rbind', .packages=c('MASS','RcppNumerical', 'pROC', 'brglm2',
                                                              'detectseparation','RcppNumerical', 'logistf', 'glmnet')) %dopar% {
    set.seed(j)
    invlogit <- function(x) {1/(1+exp(-x)) }
    
    
    bs     <- sample(nrow(data), replace=T)
    databs <- data[bs,]
    
    xbs    <- databs[,1:npred]
    ybs    <- databs[,npred+1]
    fit    <- glmnet(xbs,ybs,type.measure="deviance",family="binomial", alpha=a, standardize=TRUE, parallel=T,
                     lambda=lambdaseq, intercept = TRUE)
    
    loglikj   <- NULL
    deviancej <- NULL
    
    for (i in 1 : length(fit$lambda) ) {
      
      pred        <- invlogit(cbind(1,x)%*% coef(fit)[,i])
      loglikj[i]  <- sum(y*log(pred) + (1-y)*log(1-pred))

      pred0 <- mean(y)      
      deviancej[i] <- 2*( (sum(y*log(pred)  + (1-y)*log(1-pred))) - 
                         (sum(y*log(pred0) + (1-y)*log(1-pred0))) )
      
    }
    
    # work with deviance or log-likelihood it is the same
    # rbind(logliki)
    rbind(deviancej)
    
    
  }
  
  loglik_all    <- cvboot
  deviance_all  <- cvboot
  # lambda.ave    <- lambdaseq[colMeans(loglik_all)==max(colMeans(loglik_all))]
  lambda.ave    <- lambdaseq[colMeans(deviance_all)==max(colMeans(deviance_all))]
  
    
  fit           <- glmnet(x,y,type.measure="deviance",family="binomial", alpha=a,
                          standardize=TRUE, parallel=T, lambda=lambdaseq)
  
  beta          <- as.vector(coef(fit,s=lambda.ave) )
  
  return(list("beta.boot"=beta,"lambda.boot"=lambda.ave))
}


############################################################################################################


#'  Quick approximation of the c-statistic
#' 
#'  quickcstat
#'
#' @param y     a vector, the binary response variable
#' @param pred  a vector, the predicted outcome
#' @param seed  the seed for the random number generator
#' output: the approximated c-statistic

quickcstat<-function(y,pred,seed=1){
  
  set.seed(seed)
  casepred <-  pred[y == 1]
  conpred  <-  pred[ y==0 ]
  
  if (length(conpred) > length(casepred)){
    
    conpred    <- conpred[sample(length(conpred),length(casepred),replace = FALSE)]
    auc.true   <- sum(casepred>conpred)/length(casepred)} else 
      {
        casepred   <- casepred[sample(length(casepred),length(conpred),replace = FALSE)]
        auc.true   <- sum(casepred>conpred)/length(conpred)
        }
  
  return(auc.true)
  
}


############################################################################################################

# Calculate performance measures

#'measures
#'
#' @param xval      a matrix, the design matrix
#' @param yyval     a vector, the binary response variable
#' @param betaest   a vector, the estimated regression coefficients 
#' @param betaest   a vector, the treu regression coefficients (in simulation) 

measures <- function(yval,xval,betaest,beta.true=NULL){
  
  xval       <- as.matrix(xval)
  yval       <- as.vector(yval)
  nval       <- length(yval)
  lpest      <- cbind(1,xval)%*%betaest
  fittedest  <- invlogit(lpest)
  # slope=as.vector(coef(speedglm.wfit(yval,cbind(1,lpest),family=binomial()))[2])
  fit        <- RcppNumerical::fastLR(cbind(1,lpest), yval )
  slope      <- fit$coef[2]
  cstat      <- as.vector(roc(yval, as.vector(fittedest),quiet=TRUE)$auc)
  brier      <- sum((fittedest-yval)^2/nval)
  lptrue     <- cbind(1,xval)%*%beta.true
  fittedtrue <- invlogit(lptrue)
  mape       <- sum(abs(fittedest-fittedtrue))/nval
  rmse       <- sqrt(mean((fittedest-fittedtrue)^2))
  
  return(c(slope, cstat, brier, rmse))
}

# Additional Function for calculating performance measures
measures_example<-function(yval,xval,betaest){
  xval=as.matrix(xval)
  yval<-as.vector(yval)
  nval=length(yval)
  lpest=xval%*%betaest
  fittedest=invlogit(lpest)
  slope=as.vector(coef(speedglm.wfit(yval,cbind(1,lpest),family=binomial()))[2])
  cstat=as.vector(roc(yval, as.vector(fittedest),quiet=TRUE)$auc)
  brier=sum((fittedest-yval)^2/nval)
  return(c(slope,cstat, brier))
}

############################################################################################################

# the inverse logit function
#' @param x a vector, the linear predictor

expit     <-function(x){(1/(1+exp(-x)))}
invlogit <- function(x) {1/(1+exp(-x)) }

############################################################################################################

# Generate data for the simulation study

#'generate_data
#'
#' @param NN                   a scalar, the sample size
#' @param n.true.predictors    a scalar, the number of true predictors
#' @param n.noise.predictors   a scalar, the number of noise predictors
#' @param strength             a scalar, a multiplication factor that defines the strength of the model
#' @param cor0                 a scalar, the correlation between the true predictors 
#' @param cor1                 a scalar, the correlation between the noise predictors 
#' @param beta.0               a scalar, the intercept term 


generate_data <- function(NN, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors, 
                          strength=strength, cor0 = 0.1, cor1 = 0.05, beta.0 = beta.0){

  n.predictors <- n.true.predictors + n.noise.predictors
  mu0 <- rep(0, n.predictors)

  # Specify correlation matrix
  Sigma0 <- matrix(0, nrow = n.predictors,  ncol = n.predictors)
  Sigma0[1:n.true.predictors, 1:n.true.predictors] <- cor0
  if (n.noise.predictors>0) {
  Sigma0[(n.true.predictors+1):n.predictors, (n.true.predictors+1):n.predictors] <- cor1}
  diag(Sigma0) <- 1.0

  x <- mvrnorm(NN, mu0, Sigma0)

  beta <- c(0.5, 0.3, 0.3, 0.25, 0.25, rep(0, n.noise.predictors))*strength

  if (n.true.predictors==10)  beta <- c(rep(c(0.5, 0.3, 0.3, 0.25, 0.25),2), 
                                        rep(0, n.noise.predictors))*strength


  lp = as.vector(cbind(1, x) %*% c(beta.0,beta))
  prob = (exp(lp)/(1 + exp(lp)))
  y = rbinom(n = NN, 1, prob)

  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA

  # To check it works as expected
  # quickcstat(y,lp)
  # mean(y)

}

######################################################################################################

######################################################################################################

# Estimation of bootstrap shrinkage factor

bootsf <-function(data,n=200){
  
  cal<-NULL
  for (j in 1:n){
    bs <- sample(nrow(data), replace=T)
    databs=data[bs,]
    xvarsbs=databs[,-1];ybs<-databs[,1]
    fitbs<-withwarnings(glm.fit(cbind(1,xvarsbs),ybs,family=binomial()))
    
    while (length(fitbs$value)!=0) {
      
      bs <- sample(nrow(data), replace=T)
      databs=data[bs,]
      xvarsbs=databs[,-1];ybs<-databs[,1]
      
      fit<-withwarnings(glm.fit(cbind(1,xvarsbs),ybs,family=binomial()))
      fitbs<-fit$value
    }
    
    fitcal <- withwarnings(glm(data[,1]~as.matrix(cbind(1,data[,-1]))%*%coef(fitbs),family=binomial))
    
    if ((length(fitcal$value)!=0)){
      fitcal<-fitcal$value
      cal[j]=as.vector(coefficients(fitcal))[2]
    } else cal[j]=NA
  }
  return( median(cal,na.rm=TRUE) )
}


# Approximation of R-square from the c-statistic (from Riley et al.(2022))

#' @param auc   a scalar, the anticipated c-statistic
#' @param prev  a scalr, the outcome prevalnce 
#' @param n     a scalar, the number of simulations
#' 
#' output: the approximated R-square

approximate_R2 <- function(auc, prev, n = 1000000){
  
  # define mu as a function of the C-statistic
  mu   <- sqrt(2) * qnorm(auc)
  
  # sigmain <- sqrt(2)*qnorm(auc)
  #  mu<-0.5*(2*prev-1)*(sigmain^2)+log(prev/(1-prev))
  
  
  # simulate large sample linear prediction based on two normals
  # for non-eventsN(0, 1), events and N(mu, 1)
  
  LP <- c(rnorm(prev*n,  mean=0, sd=1), rnorm((1-prev)*n, mean=mu, sd=1))
  y <- c(rep(0, prev*n), rep(1, (1-prev)*n))
  
  # Fit a logistic regression with LP as covariate;
  # this is essentially a calibration model, and the intercept and
  # slope estimate will ensure the outcome proportion is accounted
  # for, without changing C-statistic
  
  fit <- lrm(y~LP)
  
  max_R2 <- function(prev){
    1-(prev^prev*(1-prev)^(1-prev))^2
  }
  return(list(R2.nagelkerke = as.numeric(fit$stats['R2']),
              R2.coxsnell = as.numeric(fit$stats['R2']) * max_R2(prev)))
}

######################################################################################################


# Capture warnings

withwarnings <- function(expr) {
  
  val        <- NULL
  myWarnings <- NULL
  wHandler   <- function(w) {
    myWarnings <<- c(myWarnings, w$message)
    invokeRestart("muffleWarning")
  }
  
  myError  <- NULL
  eHandler <- function(e) {
    myError <<- e$message
    NULL
  }
  val <- tryCatch(withCallingHandlers(expr, warning = wHandler), error = eHandler)
  list(value = val, warnings = myWarnings, error=myError)
}

######################################################################################################

# Bootstrap tuning (not parallelised)
#'boot_penal
#'
#' @param x  A matrix, the design matrix
#' @param y     a vector, the binary response variable
#' @param bn A scalar, the number of boostrap iterations
#' @param  methodd A string, values "ridge" or "lasso"
#' @param parallel Logical, TRUE for parallel computing

boot_penal <-function(x, y, bn=200, method="ridge", lambda=NULL, parallel=TRUE, b0632=FALSE, b0632plus=FALSE){


  if (method=="lasso") a=1
  if (method=="ridge") a=0

  fit <- glmnet(x,y,type.measure="deviance",family="binomial", alpha=a, standardize=TRUE, parallel=T)

  logliki_app <- NULL

  for (i in 1:length(fit$lambda)) {

    pred <- invlogit(cbind(1,x)%*% coef(fit)[,i])
    logliki_app[i] <- sum(y*log(pred) + (1-y)*log(1-pred))
    # or
    # logliki[i] <- -loglikelihood(coef(fit)[,i], data)/2

  }

  # no information likelihood
  pred           <- mean(y)
  gamma          <- sum(y*log(pred) + (1-y)*log(1-pred))


  lambdaseq <- fit$lambda
  lambdaseq <- unique(c(lambdaseq, seq( lambdaseq[length(lambdaseq)], lambdaseq[length(lambdaseq)]/20, -lambdaseq[length(lambdaseq)]/20 )))


  pred<-NULL; beta.boot<-NULL; lambda.boot<-NULL;cv.boot<-NULL
  yval<- y; xval = x
  npred<-ncol(x)
  data<-cbind(x,y)
  loglik     <- NULL
  lambda.min <- NULL
  loglik_all     <- NULL

  for (j in 1:(bn+1)){
    
    set.seed(j)

    bs <- sample(nrow(data), replace=T)
    databs=data[bs,]

    xbs <- databs[,1:npred]
    ybs <- databs[,npred+1]
    fit <- glmnet(xbs,ybs,type.measure="deviance",family="binomial", alpha=a, standardize=TRUE, parallel=T, lambda=lambdaseq, intercept = TRUE)

    logliki <- NULL

    for (i in 1:length(fit$lambda)) {

      pred <- invlogit(cbind(1,x)%*% coef(fit)[,i])
      logliki[i] <- sum(y*log(pred) + (1-y)*log(1-pred))
      # logliki[i] <- -loglikelihood(coef(fit)[,i], data)/2

    }

    if (b0632==TRUE)   {
       loglikinew  <- 0.368*logliki_app +0.632* logliki
       logliki <-     loglikinew
    }



    if (b0632plus==TRUE)   {
      pred        <-  mean(ybs)
      gamma       <-  sum(y*log(pred) + (1-y)*log(1-pred))
      R           <-  (logliki - logliki_app)/(gamma-logliki_app)
      omega       <-  0.632/(1-0.368*R)
      loglikinew  <-  (1-omega)*logliki_app + omega* logliki
      logliki     <-  loglikinew
    }


    loglik_all <- rbind(loglik_all, logliki)
    #plot(lambdaseq, logliki, xlim=c(0,0.5))


    loglik[j] <- max(logliki)
    lambda.min[j] =fit$lambda[logliki==loglik[j]]
  }

  #plot(lambdaseq, colMeans(loglik_all), xlim=c(0,0.5))


  lambda.ave    <- lambdaseq[colMeans(loglik_all)==max(colMeans(loglik_all))]

  lambda.med    <- median(lambda.min, na.rm=TRUE)

  lambda.ave
  lambda.med


  fit <- glmnet(x,y,type.measure="deviance",family="binomial", alpha=a, standardize=TRUE, parallel=T, lambda=lambdaseq)

  beta   <- as.vector(coef(fit,s=lambda.med) )
  beta.ave   <- as.vector(coef(fit,s=lambda.ave) )

  return(list("beta.boot"=beta,"lambda.boot"=lambda.med,  "beta.boot.ave"=beta.ave,"lambda.boot.ave"=lambda.ave))
}

########################################################################################################################

#########################################################################################################################

# Modified tuning (not parallelized)

#'mod_penal_ave
#'
#' @param x  A matrix, the design matrix
#' @param y     a vector, the binary response variable
#' @param bn A Scalar, the number of boostrap iterations
#' @param  methodd A String, values "ridge" or "lasso"Numeric where to trim (proportion)
#' @param nfolds A Scalar, the number of crossvalidaiton folds
#' @param parallel Logical, TRUE for parallel computing
#' @param parallel Logical, TRUE means sample with replacement


mod_penal_ave <- function(x, y, bn=50, method="ridge", f = nfolds/(nfolds-1)-1, parallel=TRUE, nfolds=10, boot=TRUE){
  
  if (method=="lasso") a=1
  if (method=="ridge") a=0
  
  pred  <-NULL; beta.boot<-NULL; lambda.boot<-NULL; cv.boot<-NULL
  yval  <-y; xval=x
  npred <-ncol(x)
  data <- cbind(x,y)
  
  fit <- glmnet(x,y,type.measure="deviance",family="binomial", alpha=a, standardize=TRUE, parallel=T)
  
  lambdaseq <- fit$lambda
  lambdaseq <- unique(c(lambdaseq, seq(lambdaseq[length(lambdaseq)], lambdaseq[length(lambdaseq)]/20,
                                       - lambdaseq[length(lambdaseq)]/20 )))
  
  
  cvd <- NULL
  
  for (j in 1:bn){
    
    
    bs <- sample(nrow(data), replace=T)
    databs=data[bs,]
    if (boot==FALSE) databs<-data
    
    ##
    if (f==0) databs  <- data else
    {
      bs2     <- sample(nrow(data)*f, replace=T)
      databs2 <- data[bs2,]
      databs  <- rbind(databs,databs2)
    }
    
    xbs<-databs[,1:npred];ybs<-databs[,npred+1]
    
    
    fitbs <- withwarnings(cv.glmnet(xbs,ybs,type.measure="deviance",family="binomial",alpha=a,nfolds=nfolds,
                                    standardize=TRUE, parallel = parallel, lambda=lambdaseq))
    
    
    if (length(fitbs$error)==0) {
      fitbs  <- fitbs$value
      
      cvd <- rbind(cvd, fitbs$cvm)
      
    } else
      
    {
      cvd <-cvd
    }
    
  }
  
  b <- cbind(lambdaseq, colMeans(cvd, na.rm=TRUE))
  
  b[order(b[,2]),]
  
  lambda.boot <- b[order(b[,2]),] [1,1]
  
  fit <- glmnet(x, y, type.measure = "deviance", family = "binomial", alpha=a, standardize=TRUE,
                parallel=T, lambda=lambdaseq)
  
  beta.boot   <- as.vector(coef(fit,s=lambda.boot) )
  
  
  return(list("beta.boot"=beta.boot,"lambda.boot"=lambda.boot, "cv.boot"=1))
}


######################################################################################################

#'  Calculate the median over columns
#'  colMedians
#'
#' @param df  A matrix
#'
colMedians<-function(df) apply(df,2,median)


#######################################################################################################

#' sd.trim
#' trimmed standard deviation
#'
#' compute standard deviation after trimming...
#'
#' @param x A vector
#' @param na.rm A boolean
#' @param trim Numeric where to trim (proportion)


sd.trim <- function(x, na.rm=FALSE, trim=0, ...)
{
  if(!is.numeric(x) && !is.complex(x) && !is.logical(x)) {
    warning("argument is not numeric or logical: returning NA")
    return(NA_real_)
  }
  if(na.rm) x <- x[!is.na(x)]
  if(!is.numeric(trim) || length(trim) != 1)
    stop("'trim' must be numeric of length one")
  n <- length(x)
  if(trim > 0 && n > 0) {
    if(is.complex(x)) stop("trimmed sd are not defined for complex data")
    if(trim >= 0.5) return(0)
    lo <- floor(n * trim) + 1
    hi <- n + 1 - lo
    x <- sort.int(x, partial = unique(c(lo, hi)))[lo:hi]
  }
  x <- sd(x,na.rm,...)
}

#########################################################################################################################

#DELETE FROM HERE

#########################################################################################################################


#'  Modified tuning (selection of median value of tuning parameter)
#'  mod_penal_median
#'
#' @param x  A matrix, the design matrix
#' @param y     a vector, the binary response variable
#' @param bn A Scalar, the number of bootstrap iterations
#' @param  methodd A String, values "ridge" or "lasso"Numeric where to trim (proportion)
#' @param nfolds A Scalar, the number of crossvalidation folds
#' @param parallel Logical, TRUE for parallel computing
#' @param boot Logical, TRUE means sample with replacement


mod_penal_median <- function(x, y, bn=50, method="ridge", nfolds=10, f = nfolds/(nfolds-1)-1, parallel=TRUE, boot=TRUE){
  
  if (method=="lasso") a=1
  if (method=="ridge") a=0
  
  fit <- glmnet(x,y,type.measure="deviance",family="binomial", alpha=a, standardize=TRUE, parallel=T)
  lambdaseq <- fit$lambda
  lambdaseq <- unique(c(lambdaseq, seq(lambdaseq[length(lambdaseq)],
                                       lambdaseq[length(lambdaseq)]/20, -lambdaseq[length(lambdaseq)]/20 )))
  
  
  pred  <-NULL; beta.boot<-NULL; lambda.boot<-NULL; cv.boot<-NULL
  yval  <-y; xval=x
  npred <-ncol(x)
  data <- cbind(x,y)
  
  
  for (j in 1:bn){
    
    bs <- sample(nrow(data), replace=T)
    databs=data[bs,]
    if (boot==FALSE) databs<-data
    
    if (f==0) databs  <- data else
    {
      bs2     <- sample(nrow(data)*f, replace=T)
      databs2 <- data[bs2,]
      databs  <- rbind(databs,databs2)
    }
    
    xbs<-databs[,1:npred];ybs<-databs[,npred+1]
    
    fitbs <- withwarnings(cv.glmnet(xbs,ybs,type.measure="deviance",family="binomial",alpha=a,nfolds=nfolds,
                                    standardize=TRUE, parallel = parallel, lambda=lambdaseq))
    
    
    if (length(fitbs$error)==0) {
      fitbs  <- fitbs$value
      beta   <- as.vector(coef(fitbs,s="lambda.min") )
      lambda <- fitbs$lambda.min;
      nlam<-length(fitbs$lambda)
      
      lambda.boot <-c(lambda.boot, lambda)
      data.lam    <-data.frame( fitbs$lambda.min,fitbs$cvm)
      cv<-data.lam[order(data.lam[,2]),][1,2]
      
      cv.boot<-c(cv.boot, cv)
      beta.boot<-cbind(beta.boot,beta)
      
    } else
      
    {beta<-rep(NA,npred+1); lambda<-NA
    lambda.boot <-c(lambda.boot, lambda)
    beta.boot<-cbind(beta.boot,beta)
    }
    
  }
  
  lambda.median   <-  as.numeric(quantile(lambda.boot,na.rm=TRUE,probs=seq(0,1,0.1))[6])
  fit             <-  glmnet(x=x, y=y,  alpha = a, family = 'binomial',  nfolds = nfolds, type.measure = 'deviance', lambda=lambdaseq)
  beta            <-  as.vector(coef(fit,s=lambda.median) )
  
  return(list("beta.boot"=beta,"lambda.boot"=lambda.median, "cv.boot"=cv.boot))
}


#####################################################################################################################



generate_data_bin <- function(NN, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors, 
                              strength=strength, cor0 = 0.1, cor1 = 0.05, beta.0 = beta.0){
  
  n.predictors <- n.true.predictors + n.noise.predictors
  mu0 <- rep(0, n.predictors)
  
  # Specify correlation matrix
  Sigma0 <- matrix(0, nrow = n.predictors,  ncol = n.predictors)
  Sigma0[1:n.true.predictors, 1:n.true.predictors] <- cor0
  if (n.noise.predictors>0) {
    Sigma0[(n.true.predictors+1):n.predictors, (n.true.predictors+1):n.predictors] <- cor1}
  diag(Sigma0) <- 1.0
  
  x <- mvrnorm(NN, mu0, Sigma0)
  x[,1] <- ifelse(x[,1]>qnorm(0.9),0,1)
  x[,1] <- scale(x[,1])
  x[,3] <- ifelse(x[,3]>qnorm(0.6),0,1)
  x[,3] <- scale(x[,3])
  x[,5] <- ifelse(x[,5]>qnorm(0.5),0,1)
  x[,5] <- scale(x[,5])
  x[,7] <- ifelse(x[,7]>qnorm(0.6),0,1)
  x[,7] <- scale(x[,7])
  x[,9] <- ifelse(x[,9]>qnorm(0.5),0,1)
  x[,9] <- scale(x[,9])
  
  
  beta <- c(0.6, 0.3, 0.3, 0.25, 0.25, rep(0, n.noise.predictors))*strength
  
  if (n.true.predictors==10)  beta <- c(rep(c(0.6, 0.3, 0.3, 0.25, 0.25),2), rep(0, n.noise.predictors))*strength
  
  
  lp = as.vector(cbind(1, x) %*% c(beta.0,beta))
  prob = (exp(lp)/(1 + exp(lp)))
  y = rbinom(n = NN, 1, prob)
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

#################################################################################################################

generate_data_res <- function(NN, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors,
                              strength=strength, cor0 = 0.1, cor1 = 0.05, beta.0 = beta.0){
  
  n.predictors <- n.true.predictors + n.noise.predictors
  mu0 <- rep(0, n.predictors)
  
  # Specify correlation matrix
  Sigma0 <- matrix(0, nrow = n.predictors,  ncol = n.predictors)
  Sigma0[1:n.true.predictors, 1:n.true.predictors] <- cor0
  if (n.noise.predictors>0) {
    Sigma0[(n.true.predictors+1):n.predictors, (n.true.predictors+1):n.predictors] <- cor1}
  diag(Sigma0) <- 1.0
  
  beta <- c(0.5, 0.3, 0.3, 0.25, 0.25, rep(0, n.noise.predictors))*strength
  
  if (n.true.predictors==10)  beta <- c(rep(c(0.5, 0.3, 0.3, 0.25, 0.25),2), rep(0, n.noise.predictors))*strength
  
  xall <- mvrnorm(500000, mu0, Sigma0)
  #lp = as.vector(cbind(1, x) %*% c(beta.0,beta))
  #prob = (exp(lp)/(1 + exp(lp)))
  #y = rbinom(n = NN, 1, prob)
  yall = rbinom(n = 500000, 1, invlogit(as.vector(cbind(1, xall) %*% c(beta.0,beta))))
  
  
  data_all<-cbind(yall, xall)
  events    <-data_all[data_all[,1]==1,]
  nonevents <-data_all[data_all[,1]==0,]
  
  p <- mean(yall)
  
  
  events_s   <- events[sample(nrow(events),round(NN*p)),]
  nonevents_s <- nonevents[sample(nrow(nonevents), NN-nrow(events_s)),]
  
  data<-rbind(events_s, nonevents_s)
  y<-data[,1]
  x<-data[,-1]
  
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

####################################################################################################################

generate_data_m <- function(NN, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors,
                            beta0=0,cor0=0.1, cor1=0.05, multiply=1){
  
  RhoX<-0
  
  
  if (n.true.predictors==5)   betas   <- c(0.5, 0.3, 0.3, 0.25, 0.25, rep(0, n.noise.predictors))*multiply
  
  if (n.true.predictors==10)  betas   <- c(rep(c(0.5, 0.3, 0.3, 0.25, 0.25),2), rep(0, n.noise.predictors))*multiply
  
  
  #betas <- c(0.5, 0.3, 0.3, 0.25, 0.25, 0.0, 0.05, 0.05, 0.05, 0.05)
  
  n.predictors <- n.true.predictors + n.noise.predictors
  mu0 <- rep(0, n.predictors)
  
  # Specify correlation matrix
  Sigma0 <- matrix(0, nrow = n.predictors,  ncol = n.predictors)
  Sigma0[1:n.true.predictors, 1:n.true.predictors] <- cor0
  if (n.noise.predictors>0) {
    Sigma0[(n.true.predictors+1):n.predictors, (n.true.predictors+1):n.predictors] <- cor1}
  diag(Sigma0) <- 1.0
  
  x <- mvrnorm(NN, mu0, Sigma0)
  
  lp = as.vector(cbind(1, x) %*% c(beta0,betas))
  prob = (exp(lp)/(1 + exp(lp)))
  y = rbinom(n = NN, 1, prob)
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

#########################################################################################################################

generate_data_m2 <- function(NN, n.true.predictors = n.true.predictors, 
                             n.noise.predictors = n.noise.predictors,beta0=0){
  
  RhoX<-0
  
  
  if (n.true.predictors==5) betas  <-  c(rep(log(1.10), 6), rep(log(1.5), 2), rep(log(2), 2), rep(0,n.noise.predictors))
  
  
  if (n.true.predictors==10) betas <- c(rep(log(1.10), 6), rep(log(1.5), 2), rep(log(2), 2), rep(0,n.noise.predictors))
  
  
  
  #betas <- c(0.5, 0.3, 0.3, 0.25, 0.25, 0.0, 0.05, 0.05, 0.05, 0.05)
  
  Sigma.mat <- diag(1, ncol = P, nrow = P)
  #Create pair-wise correlations:
  if (P <= 2) {
    Sigma.mat[upper.tri(Sigma.mat)] <- Sigma.mat[lower.tri(Sigma.mat)] <- RhoX
  } else{
    Sigma.mat[(row(Sigma.mat) - col(Sigma.mat)) == 1 |
                (row(Sigma.mat) - col(Sigma.mat)) == -1][c(TRUE, TRUE, FALSE, FALSE)] <- RhoX
  }
  
  beta<-c(beta0,betas)
  x <- MASS::mvrnorm(n = NN, mu = rep(0, P), Sigma = Sigma.mat)
  LP = as.vector(cbind(1, x) %*% beta)
  Pi = (exp(LP)/(1 + exp(LP)))
  y = rbinom(n = NN, 1, Pi)
  #roc(y,LP)
  
  
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

######################################################################################################

generate_data_vc <- function(NN, n.true.predictors = n.true.predictors, 
                             n.noise.predictors = n.noise.predictors,beta0=0){
  
  RhoX<-0
  
  betas= c(0.2,0.2, 0.2, 0.5, 0.8,rep(0,n.noise.predictors))
  
  P<-length(betas)
  
  
  #betas <- c(0.5, 0.3, 0.3, 0.25, 0.25, 0.0, 0.05, 0.05, 0.05, 0.05)
  
  Sigma.mat <- diag(1, ncol = P, nrow = P)
  #Create pair-wise correlations:
  if (P <= 2) {
    Sigma.mat[upper.tri(Sigma.mat)] <- Sigma.mat[lower.tri(Sigma.mat)] <- RhoX
  }else{
    Sigma.mat[(row(Sigma.mat) - col(Sigma.mat)) == 1 |
                (row(Sigma.mat) - col(Sigma.mat)) == -1][c(TRUE, TRUE, FALSE, FALSE)] <- RhoX
  }
  
  beta<-c(beta0,betas)
  x <- MASS::mvrnorm(n = NN, mu = rep(0, P), Sigma = Sigma.mat)
  LP = as.vector(cbind(1, x) %*% beta)
  Pi = (exp(LP)/(1 + exp(LP)))
  y = rbinom(n = NN, 1, Pi)
  #roc(y,LP)
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

#########################################################################################################################

# Heuristic shrinkage factor

shrink.heur <- function (dataset, model, DF, int = TRUE, int.adj = FALSE) {
  
  if (missing(model))
    stop("Type of model must be specified in the function call")
  if (int == FALSE)
    stop("For heuristic methods, an intercept must be included in\n                        the regression")
  if (missing(DF))
    warning("The number of degrees of freedom used by predictors was\n                          estimated automatically")
  if (missing(DF))
    DF <- dim(dataset)[2] - 2
  dataset <- as.matrix(dataset)
  nc <- dim(dataset)[2]
  if (model == "linear") {
    Rsq <- function(dataset) {
      nc <- dim(dataset)[2]
      b <- ols.rgr(dataset)
      y <- dataset[, nc]
      X <- dataset[, 1:(nc - 1)]
      yhat <- (X %*% b)
      res <- y - yhat
      sse0 <- t(res) %*% res
      scale(y, center = TRUE, scale = FALSE)
      Syy <- t(y) %*% y
      r <- 1 - (sse0/Syy)
    }
    b <- ols.rgr(dataset)
    R2 <- Rsq(dataset)
    n <- dim(dataset)[1]
    AdjR2 <- 1 - (1 - R2) * (n - 1)/(n - DF - 1)
    s <- (n - DF - 1)/(n - 1) * AdjR2/R2
  }
  else if (model == "logistic") {
    b <- ml.rgr(dataset)
    y <- dataset[, nc]
    d0 <- cbind(1, y)
    b0 <- ml.rgr(d0)
    b0 <- matrix(c(b0, rep(0, nc - 2)), ncol = 1)
    model.chisq <- loglikelihood(b0, dataset) - loglikelihood(b,
                                                              dataset)
    s <- ((model.chisq - DF)/model.chisq)
  }
  if (int.adj == FALSE) {
    b.shrunk <- b
    y <- dataset[, nc]
    bl <- dim(b.shrunk)[1]
    b.shrunk[1] <- (1 - s) * mean(y) + s * b[1]
    b.shrunk[2:bl] <- b[2:bl] * s
  }
  else {
    b.shrunk <- matrix(s * b[2:length(b)], ncol = 1)
    if (model == "linear") {
      new.int <- mean((dataset[, nc]) - ((dataset[, 2:(nc -
                                                         1)]) %*% b.shrunk))
      b.shrunk <- c(new.int, b.shrunk)
    }
    else {
      X.i <- matrix(dataset[, 1], ncol = 1)
      Y <- dataset[, nc]
      offs <- as.vector((dataset[, 2:(nc - 1)]) %*% b.shrunk)
      new.int <- glm.fit(X.i, Y, family = binomial(link = "logit"),
                         offset = offs)$coefficients
      b.shrunk <- c(new.int, b.shrunk)
    }
  }
  return(list(raw.coeff = b, shrunk.coeff = matrix(b.shrunk,
                                                   ncol = 1), lambda = s, DF = DF))
}

ml.rgr <- function (dataset) {
  nc <- dim(dataset)[2]
  X <- dataset[, 1:nc - 1]
  Y <- dataset[, nc]
  ml.fit <- glm.fit(X, Y, family = binomial(link = "logit"))
  coeffs <- as.matrix(ml.fit$coefficients, ncol = 1)
  return(coeffs)
}



######################################################################################################

# Boostrap validation

bootval<- function (dataset, model, N, sdm, int = TRUE, int.adj) {
  m <- dim(dataset)[1]
  nc <- dim(dataset)[2]
  s <- c(rep(0, N))
  if (missing(sdm)) {
    if (int == FALSE)
      sdm <- matrix(rep(1, nc - 1), nrow = 1)
    else sdm <- matrix(c(0, rep(1, nc - 2)), nrow = 1)
  }
  if (int == FALSE)
    int.adj <- FALSE
  if (int == TRUE & missing(int.adj))
    int.adj <- TRUE
  if (model == "linear") {
    for (k in 1:N) {
      indces <- sample(m, replace = TRUE)
      dboot <- dataset[indces, ]
      b <- ols.rgr(dboot)
      s[k] <- ols.shrink(b, dataset, sdm)
    }
    lambda <- mean(s)
    betas <- ols.rgr(dataset)
    sdm <- t(sdm)
    B.shrunk <- matrix(diag(as.vector(betas)) %*% sdm %*%
                         lambda + diag(as.vector(betas)) %*% apply(1 - sdm,
                                                                   1, min), ncol = 1)
    if (int.adj == TRUE) {
      new.int <- mean((dataset[, nc]) - ((dataset[, 2:(nc -
                                                         1)]) %*% B.shrunk[-1]))
      B.shrunk <- c(new.int, B.shrunk[-1])
    }
    return(list(raw.coeff = betas, shrunk.coeff = matrix(B.shrunk,
                                                         ncol = 1), lambda = lambda, N = N, sdm = t(sdm)))
  }
  else {
    for (k in 1:N) {
      indces <- sample(m, replace = TRUE)
      dboot <- dataset[indces, ]
      b <- ml.rgr(dboot)
      s[k] <- ml.shrink(b, dataset)
    }
    lambda <- mean(s)
    betas <- ml.rgr(dataset)
    sdm <- t(sdm)
    B.shrunk <- matrix(diag(as.vector(betas)) %*% sdm %*%
                         lambda + diag(as.vector(betas)) %*% apply(1 - sdm,
                                                                   1, min), ncol = 1)
    if (int.adj == TRUE) {
      dataset <- as.matrix(dataset)
      X.i <- matrix(dataset[, 1], ncol = 1)
      Y <- dataset[, nc]
      offs <- as.vector((dataset[, 2:(nc - 1)]) %*% B.shrunk[-1])
      new.int <- glm.fit(X.i, Y, family = binomial(link = "logit"),
                         offset = offs)$coefficients
      B.shrunk <- c(new.int, B.shrunk[-1])
    }
    return(list(raw.coeff = betas, shrunk.coeff = matrix(B.shrunk,
                                                         ncol = 1), lambda = lambda, N = N, sdm = t(sdm)))
  }
}

######################################################################################################

approximate_R2_imp <- function(auc, prev, n = 1000000){
  
  # define mu as a function of the C-statistic
  mu   <- sqrt(2) * qnorm(auc)
  
  sigmain <- sqrt(2)*qnorm(auc)
  mu<-0.5*(2*prev-1)*(sigmain^2)+log(prev/(1-prev))
  sigma<-sqrt((sigmain^2)*(1+prev*(1-prev)*(sigmain^2)))
  
  
  # simulate large sample linear prediction based on two normals
  # for non-eventsN(0, 1), events and N(mu, 1)
  
  LP <- c(rnorm(prev*n,  mean=0, sd=1), rnorm((1-prev)*n, mean=mu, sd=1))
  y <- c(rep(0, prev*n), rep(1, (1-prev)*n))
  LP <- rnorm(n,mu,sigma)
  y<-rbinom(n,1, 1/(1+exp(-LP)))
  
  # Fit a logistic regression with LP as covariate;
  # this is essentially a calibration model, and the intercept and
  # slope estimate will ensure the outcome proportion is accounted
  # for, without changing C-statistic
  
  fit <- lrm(y~LP)
  
  max_R2 <- function(prev){
    1-(prev^prev*(1-prev)^(1-prev))^2
  }
  return(list(R2.nagelkerke = as.numeric(fit$stats['R2']),
              R2.coxsnell = as.numeric(fit$stats['R2']) * max_R2(prev)))
  
}


############################################################################################################



generate_data_bin <- function(NN, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors,
                              strength=strength, cor0 = 0.1, cor1 = 0.05, beta.0 = beta.0){
  
  n.predictors <- n.true.predictors + n.noise.predictors
  mu0 <- rep(0, n.predictors)
  
  # Specify correlation matrix
  Sigma0 <- matrix(0, nrow = n.predictors,  ncol = n.predictors)
  Sigma0[1:n.true.predictors, 1:n.true.predictors] <- cor0
  if (n.noise.predictors>0) {
    Sigma0[(n.true.predictors+1):n.predictors, (n.true.predictors+1):n.predictors] <- cor1}
  diag(Sigma0) <- 1.0
  
  x <- mvrnorm(NN, mu0, Sigma0)
  x[,1] <- ifelse(x[,1]>qnorm(0.9),0,1)
  x[,1] <- scale(x[,1])
  x[,3] <- ifelse(x[,3]>qnorm(0.6),0,1)
  x[,3] <- scale(x[,3])
  x[,5] <- ifelse(x[,5]>qnorm(0.5),0,1)
  x[,5] <- scale(x[,5])
  x[,7] <- ifelse(x[,7]>qnorm(0.6),0,1)
  x[,7] <- scale(x[,7])
  x[,9] <- ifelse(x[,9]>qnorm(0.5),0,1)
  x[,9] <- scale(x[,9])
  
  
  beta <- c(0.6, 0.3, 0.3, 0.25, 0.25, rep(0, n.noise.predictors))*strength
  
  if (n.true.predictors==10)  beta <- c(rep(c(0.6, 0.3, 0.3, 0.25, 0.25),2), rep(0, n.noise.predictors))*strength
  
  
  lp = as.vector(cbind(1, x) %*% c(beta.0,beta))
  prob = (exp(lp)/(1 + exp(lp)))
  y = rbinom(n = NN, 1, prob)
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

######################################################################################################


generate_data_res <- function(NN, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors,
                              strength=strength, cor0 = 0.1, cor1 = 0.05, beta.0 = beta.0){
  
  n.predictors <- n.true.predictors + n.noise.predictors
  mu0 <- rep(0, n.predictors)
  
  # Specify correlation matrix
  Sigma0 <- matrix(0, nrow = n.predictors,  ncol = n.predictors)
  Sigma0[1:n.true.predictors, 1:n.true.predictors] <- cor0
  if (n.noise.predictors>0) {
    Sigma0[(n.true.predictors+1):n.predictors, (n.true.predictors+1):n.predictors] <- cor1}
  diag(Sigma0) <- 1.0
  
  beta <- c(0.5, 0.3, 0.3, 0.25, 0.25, rep(0, n.noise.predictors))*strength
  
  if (n.true.predictors==10)  beta <- c(rep(c(0.5, 0.3, 0.3, 0.25, 0.25),2), rep(0, n.noise.predictors))*strength
  
  xall <- mvrnorm(500000, mu0, Sigma0)
  #lp = as.vector(cbind(1, x) %*% c(beta.0,beta))
  #prob = (exp(lp)/(1 + exp(lp)))
  #y = rbinom(n = NN, 1, prob)
  yall = rbinom(n = 500000, 1, invlogit(as.vector(cbind(1, xall) %*% c(beta.0,beta))))
  
  
  data_all<-cbind(yall, xall)
  events    <-data_all[data_all[,1]==1,]
  nonevents <-data_all[data_all[,1]==0,]
  
  p <- mean(yall)
  
  
  events_s   <- events[sample(nrow(events),round(NN*p)),]
  nonevents_s <- nonevents[sample(nrow(nonevents), NN-nrow(events_s)),]
  
  data<-rbind(events_s, nonevents_s)
  y<-data[,1]
  x<-data[,-1]
  
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

######################################################################################################

generate_data_m <- function(NN, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors,
                            beta0=0,cor0=0.1, cor1=0.05, multiply=1){
  
  RhoX<-0
  
  
  if (n.true.predictors==5)   betas   <- c(0.5, 0.3, 0.3, 0.25, 0.25, rep(0, n.noise.predictors))*multiply
  
  if (n.true.predictors==10)  betas   <- c(rep(c(0.5, 0.3, 0.3, 0.25, 0.25),2), rep(0, n.noise.predictors))*multiply
  
  
  #betas <- c(0.5, 0.3, 0.3, 0.25, 0.25, 0.0, 0.05, 0.05, 0.05, 0.05)
  
  n.predictors <- n.true.predictors + n.noise.predictors
  mu0 <- rep(0, n.predictors)
  
  # Specify correlation matrix
  Sigma0 <- matrix(0, nrow = n.predictors,  ncol = n.predictors)
  Sigma0[1:n.true.predictors, 1:n.true.predictors] <- cor0
  if (n.noise.predictors>0) {
    Sigma0[(n.true.predictors+1):n.predictors, (n.true.predictors+1):n.predictors] <- cor1}
  diag(Sigma0) <- 1.0
  
  x <- mvrnorm(NN, mu0, Sigma0)
  
  lp = as.vector(cbind(1, x) %*% c(beta0,betas))
  prob = (exp(lp)/(1 + exp(lp)))
  y = rbinom(n = NN, 1, prob)
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

######################################################################################################


generate_data_m2 <- function(NN, n.true.predictors = n.true.predictors, 
                             n.noise.predictors = n.noise.predictors,beta0=0){
  
  RhoX<-0
  
  
  if (n.true.predictors==5) betas= c(rep(log(1.10), 6), rep(log(1.5), 2), rep(log(2), 2), rep(0,n.noise.predictors))
  
  
  if (n.true.predictors==10) betas       <- c(rep(log(1.10), 6), rep(log(1.5), 2), rep(log(2), 2), rep(0,n.noise.predictors))
  
  
  
  #betas <- c(0.5, 0.3, 0.3, 0.25, 0.25, 0.0, 0.05, 0.05, 0.05, 0.05)
  
  Sigma.mat <- diag(1, ncol = P, nrow = P)
  #Create pair-wise correlations:
  if (P <= 2) {
    Sigma.mat[upper.tri(Sigma.mat)] <- Sigma.mat[lower.tri(Sigma.mat)] <- RhoX
  } else{
    Sigma.mat[(row(Sigma.mat) - col(Sigma.mat)) == 1 |
                (row(Sigma.mat) - col(Sigma.mat)) == -1][c(TRUE, TRUE, FALSE, FALSE)] <- RhoX
  }
  
  beta<-c(beta0,betas)
  x <- MASS::mvrnorm(n = NN, mu = rep(0, P), Sigma = Sigma.mat)
  LP = as.vector(cbind(1, x) %*% beta)
  Pi = (exp(LP)/(1 + exp(LP)))
  y = rbinom(n = NN, 1, Pi)
  #roc(y,LP)
  
  
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

######################################################################################################

generate_data_vc <- function(NN, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors,beta0=0){
  
  RhoX<-0
  
  betas= c(0.2,0.2, 0.2, 0.5, 0.8,rep(0,n.noise.predictors))
  
  P<-length(betas)
  
  
  #betas <- c(0.5, 0.3, 0.3, 0.25, 0.25, 0.0, 0.05, 0.05, 0.05, 0.05)
  
  Sigma.mat <- diag(1, ncol = P, nrow = P)
  #Create pair-wise correlations:
  if (P <= 2) {
    Sigma.mat[upper.tri(Sigma.mat)] <- Sigma.mat[lower.tri(Sigma.mat)] <- RhoX
  }else{
    Sigma.mat[(row(Sigma.mat) - col(Sigma.mat)) == 1 |
                (row(Sigma.mat) - col(Sigma.mat)) == -1][c(TRUE, TRUE, FALSE, FALSE)] <- RhoX
  }
  
  beta<-c(beta0,betas)
  x <- MASS::mvrnorm(n = NN, mu = rep(0, P), Sigma = Sigma.mat)
  LP = as.vector(cbind(1, x) %*% beta)
  Pi = (exp(LP)/(1 + exp(LP)))
  y = rbinom(n = NN, 1, Pi)
  #roc(y,LP)
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

######################################################################################################

# Parametric boostrap

bootsf_param<-function(data,n=200){
  
  datasf<-data.frame(datasf)
  x <- datasf[,-1]
  y<-datasf[,1]
  fit   <- glm(y~., data=datasf, family="binomial")
  beta  <- coef(fit)
  vbeta <- vcov(fit)
  
  cal<-NULL
  for (j in 1:n){
    
    beta_bs <- as.vector(rmvnorm(1, beta, vbeta))
    #ybs     <- rbinom(nrow(x), 1,invlogit(as.matrix(cbind(1,x))%*%beta_bs))
    #fitbs<-glm.fit(cbind(1,x),ybs,family=binomial())
    #beta <- as.vector(coef(fitbs))
    
    fitcal <- glm(datasf[,1]~as.matrix(cbind(1,x))%*%beta_bs,family=binomial)
    cal[j]=as.vector(coefficients(fitcal))[2]
  }
  
  return( median(cal,na.rm=TRUE) )
}


######################################################################################################


generate_data_sep <- function(NN, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors, strength=strength, cor0 = 0.1, cor1 = 0.05, beta.0 = beta.0){
  
  n.predictors <- n.true.predictors + n.noise.predictors
  mu0 <- rep(0, n.predictors)
  
  # Specify correlation matrix
  Sigma0 <- matrix(0, nrow = n.predictors,  ncol = n.predictors)
  Sigma0[1:n.true.predictors, 1:n.true.predictors] <- cor0
  if (n.noise.predictors>0) {
    Sigma0[(n.true.predictors+1):n.predictors, (n.true.predictors+1):n.predictors] <- cor1}
  diag(Sigma0) <- 1.0
  
  x <- mvrnorm(NN, mu0, Sigma0)
  
  beta <- c(4, 2, 0.1, 0.1, 0.1, rep(0, n.noise.predictors))*strength
  
  if (n.true.predictors==10)  beta <- c(rep(c(2, 0.3, 0.3, 0.25, 0.25),2), rep(0, n.noise.predictors))*strength
  
  
  x[,1] <- rbinom(NN, 1, 0.05)
  x[,2] <- rbinom(NN, 1, 0.05)
  
  
  lp = as.vector(cbind(1, x) %*% c(beta.0,beta))
  prob = (exp(lp)/(1 + exp(lp)))
  y = rbinom(n = NN, 1, prob)
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  
}

loglikelihood <- function (b, dataset)
{
  dataset <- as.matrix(dataset)
  b <- matrix(b, ncol = 1)
  nc <- dim(dataset)[2]
  y <- dataset[, nc]
  n <- length(y)
  DS <- dataset
  DS <- DS[, 1:nc - 1]
  linear <- DS %*% b
  z <- t(y) %*% linear - rep(1, n) %*% log(1 + exp(linear))
  z <- -2 * z
  return(z)
}

generate_data_vs <- function(NN, n.predictors, cor = 0.2){
  
  n.noise   <- round(n.predictors/4)
  n.weak    <- round(n.predictors/4)
  n.strong  <- round(n.predictors/2)
  
  # Specify correlation matrix
  Sigma0 <- matrix(0, nrow = n.predictors,  ncol = n.predictors)
  Sigma0[1:n.predictors, 1:n.predictors] <- cor
  diag(Sigma0) <- 1.0
  
  
  x     <- mvrnorm(NN, rep(0, n.predictors), Sigma0)
  ncol(x)
  
  if (n.predictors == 8)  {beta0 <- -1.04 ;   f <- 0.2}
  if (n.predictors == 16) {beta0 <- -1.04 ;   f <- 0.2}
  
  beta <- c(beta0, f*c(rep(1, n.strong), rep(0.5, n.weak), rep(0, n.noise)))
  
  lp = as.vector(cbind(1, x) %*% beta)
  prob = (exp(lp)/(1 + exp(lp)))
  y = rbinom(n = NN, 1, prob)
  
  DATA   <- data.frame(x)
  DATA$y <- y * 1
  DATA
  # quickcstat(y,lp)
  # mean(y)
}


######################################################################################################

