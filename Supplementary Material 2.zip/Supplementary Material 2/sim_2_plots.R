# Make sure path is ok

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

###########################################################################################

# Code to produce (and save to folder 'ifigures_tables')

# Figures 3,4
# Figures S1-S7

###########################################################################################

# Install packages if needed

load.lib <-c("MASS","tidyverse", "patchwork", "plyr","ggplot2", "blorr",
             "DescTools", "ggpubr", "plotly", "GGally",  "plyr","scales", "RColorBrewer")

# Then we select only the packages that aren't currently installed.

install.lib <- load.lib[!load.lib %in% installed.packages()]

# And finally we install the missing packages, including their dependency.
for (lib in install.lib) install.packages(lib,dependencies=TRUE)

# After the installation process completes, we load all packages.
sapply(load.lib,require,character=TRUE)


###########################################################################################

# Load data

load("intermediate_results/penalised_p_05.Rdata")

out_p<-arrange(out_p, method)


out_p$method = factor(out_p$method)
levels(out_p$method) = c("MLE", "Firth","Boot-Unif", "Heur-Unif", "Ridge", "Mod-Ridge",
                         "Boot-Ridge", "Lasso", "Mod-Lasso", "Boot-Lasso")

myColors <- brewer.pal(10, "Spectral")
names(myColors) <- levels(out_p$method)
custom_colors <- scale_colour_manual(name = "Method", values = myColors)


out_p$ms = factor(out_p$c_true)

low    <- paste("C=",round(inputs$c_true[1],2));
high   <- paste("C=",round(inputs$c_true[2],2));

out_p$ms<- low
out_p$ms[out_p$strength==inputs$strength[2]]<-high
out_p$ms <- factor(out_p$ms, levels=c(low, high))


### C-stat=0.7 (low model strength) ###

k<-1


toplot <-out_p%>%
  filter(ms==low)%>%
  filter(method!="Heur-Unif")

toplot$size = factor(toplot$epv)
levels(toplot$size) = c("N/2", "3N/4", "N", "5N/4")

toplot$slope[toplot$slope<0] <- 0.1
toplot$slope[toplot$slope>10] <- 10

N   <- unique(toplot$epv)*n.predictors/prev
N   <- round(N/10)*10
epv <- round(unique(toplot$epv),1)


toplot$prob_cs  <- ifelse(toplot$slope>=0.9 & toplot$slope<=1.1,1,0)

toplot$error    <- (1-toplot$slope)^2
toplot$logerror    <- (log(1)-log(toplot$slope))^2

  scale_fill_shrinkage <- function(...){
    ggplot2:::manual_scale(
      'fill',
      values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
      ...
    )
  }

  scale_col_shrinkage <- function(...){
    ggplot2:::manual_scale(
      'col',
      values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
      ...
    )
  }


#####################################################################################################

###### Figures 3,4 #########

toplot <- toplot %>% dplyr::select(-lambda)%>%filter(method!="Heur-Unif")

toplot <-na.omit(toplot)


# Calibration slope

cs_plot_low <- ggplot(toplot,
  aes(x=size, y=slope, fill=method)) +
  geom_hline(yintercept=1,linetype="dashed") +
  geom_boxplot() + ylab("Calibr. Slope (log-scale)") + xlab("Sample Size") +
  theme_bw()+
  theme(legend.position="bottom")+
  scale_y_continuous(breaks=c(0,0.5,0.8, 0.9,1,1.1,1.5,2.5), limits = c(0.5, 2.5),trans="log10") +
  labs(fill="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", fill="Method") + scale_fill_shrinkage() +
  guides(color=guide_legend(nrow=2, byrow=FALSE)) +
  ggplot2::theme(text =  ggplot2::element_text(size = 15))

# C-statistic

cstat_plot_low <- ggplot(toplot,
  aes(x=size, y=c_est, fill=method)) +
  geom_boxplot()  + ylab("C-statistic")+ xlab("EPV")+
  theme_bw()+
  theme(legend.position="bottom")  +
  labs(fill="method")+
  labs(shape="Method", fill="Method") + scale_fill_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 15))

# Root Mean Square prediction Error

rmse_plot_low <- ggplot(toplot, aes(x=size, y=rmse, fill=method)) +
  geom_boxplot() + ylab("RMSPE")+ xlab("EPV")+
  theme_bw()+
  theme(legend.position="bottom")  +
  labs(fill="method")+
  labs(shape="Method", fill="Method") + scale_fill_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 15))



figure <- ggarrange(cs_plot_low, cstat_plot_low, rmse_plot_low,
                    #labels = c("        A", "        B"),
                    ncol = 3, nrow = 1, common.legend = TRUE, legend="bottom")

measures_low <- annotate_figure(figure,
                               top = text_grob(paste("Calibration Slope, C-statistic and Root Mean Square Prediction Error (RMSPE) \n",
                                                     "Prevalence = ",toplot$prev[1], ", C-statistic = ",toplot$c_true[1],
                                                     ", N = ",N[1]*2,sep=""),
                                               color = "black", face = "bold", size = 15))

figure_3 <- measures_low
figure_3

ggsave("figures_tables/figure_3.pdf", width=13, height=5)
ggsave("figures_tables/figure_3.tiff", width=13, height=5, dpi=300)


#### Measures variability #####

# Probability of well calibrated model

prob_cs <-ddply(toplot, c("size","method","ms"),
                summarise, value = mean(prob_cs,na.rm=TRUE))

# Root mean square deviation of the log calibration slope

rmsdlog_cs <-ddply(toplot,c("size","method","ms"),
                summarise, value = sqrt(mean(logerror,na.rm=TRUE)))

rmsd_cs <-ddply(toplot,c("size","method","ms"),
                   summarise, value = sqrt(mean(error,na.rm=TRUE)))


# prob_cs_low <- ggplot(prob_cs %>% filter(method!="Mod-Ridge" & method!="Mod-Lasso"),
  prob_cs_low <- ggplot(prob_cs %>% filter(method!="Boot-Ridge" & method!="Boot-Lasso"),
                      aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("Probability of CS in [0.9,1.1]")+ xlab("Sample Size")+
  theme_bw() +
  geom_hline(yintercept = prob_cs$value[19], linetype="dashed",size=1)+
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13)) + 
    scale_x_discrete(expand = c(0.05,0))


# rmsdlog_cs_low <- ggplot(rmsdlog_cs %>% filter(method!="Mod-Ridge" & method!="Mod-Lasso"),
rmsdlog_cs_low <- ggplot(rmsdlog_cs %>% filter(method!="Boot-Ridge" & method!="Boot-Lasso"),
                                              aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("RMSD log(Calibration Slope)")+ xlab("Sample Size") +
  geom_hline(yintercept = rmsdlog_cs$value[19], linetype="dashed",size=1)+
  theme_bw() +
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13)) + 
  scale_x_discrete(expand = c(0.05,0))


figure <- ggarrange(rmsdlog_cs_low, prob_cs_low,
                    #labels = c("        A", "        B"),
                    ncol = 2, nrow = 1, common.legend = TRUE, legend="bottom")

measures_var_low <- annotate_figure(figure,
                                   top = text_grob(paste("Combining bias and variability in the estimated Calibration Slope \n Prevalence = ",
                                                         toplot$prev[1], ", C-statistic = ",toplot$c_true[1], ", N = ",N[1]*2, sep=""),
                                                   color = "black", face = "bold", size = 13))

 figure_4 <- measures_var_low
 figure_4

 ggsave("figures_tables/figure_4.pdf",width=9, heigh=5)
 ggsave("figures_tables/figure_4.tiff",width=9, heigh=5, dpi=300)


 #########################################################################################################################################


 #### Supplementary figures  #####

 #### Bootstrap shrinkage vs modified shrinkage

load("intermediate_results/penalised_p_05.Rdata")

out_p$method = factor(out_p$method)
levels(out_p$method) = c("MLE", "Firth","Boot-Unif", "Heur-Unif", "Ridge", "Mod-Ridge", "Boot-Ridge", "Lasso", "Mod-Lasso", "Boot-Lasso")

myColors <- brewer.pal(10, "Spectral")
names(myColors) <- levels(out_p$method)
custom_colors <- scale_colour_manual(name = "Method", values = myColors)


out_p$ms = factor(out_p$c_true)

low    <- paste("C=",round(inputs$c_true[1],2));
high   <- paste("C=",round(inputs$c_true[2],2));

out_p$ms<- low
out_p$ms[out_p$strength==inputs$strength[2]]<-high
out_p$ms <- factor(out_p$ms, levels=c(low, high))

k<-1

toplot <-out_p%>%
  filter(ms==low)%>%
  filter(method!="Heur-Unif")
#filter(method!="Heur-Unif" & method!="Mod-Lasso" & method !="Mod-Ridge")


toplot$size = factor(toplot$epv)
levels(toplot$size) = c("N/2", "3N/4", "N", "5N/4")

N   <- unique(toplot$epv)*n.predictors/prev
N   <- round(N/10)*10

toplot$slope[toplot$slope<0] <- 0.1
toplot$slope[toplot$slope>10] <- 10


toplot$prob_cs  <- ifelse(toplot$slope>=0.9 & toplot$slope<=1.1,1,0)

toplot$error    <- (1-toplot$slope)^2
toplot$logerror    <- (log(1)-log(toplot$slope))^2


 toplot <- toplot%>%filter(method=="MLE" |  method=="Firth" | method=="Boot-Unif"|  method=="Ridge"| method=="Lasso"| method=="Mod-Ridge" | method=="Boot-Ridge" | method=="Mod-Lasso" | method=="Boot-Lasso")

toplot <- toplot %>% dplyr::select(-lambda)

toplot <-na.omit(toplot)

scale_fill_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'fill',
    values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}

scale_col_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'col',
    values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}


# Calibration slope

cs_plot_low <- ggplot(toplot,
                      aes(x=size, y=slope, fill=method)) +
  geom_hline(yintercept=1,linetype="dashed") +
  geom_boxplot() + ylab("Calibration Slope")+ xlab("Sample Size")+
  theme_bw()+
  theme(legend.position="bottom")+
  scale_y_continuous(limits = c(0.5, 2.5), breaks=c(0.5, 0.7, 0.9, 1, 1.1, 1.5, 2, 2.5),trans="log10") +
  labs(fill="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", fill="Method") + scale_fill_shrinkage() +
  guides(color=guide_legend(nrow=2, byrow=FALSE)) +
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


rmse_plot_low <- ggplot(toplot, aes(x=size, y=rmse, fill=method)) +
  geom_boxplot() + ylab("RMSPE")+ xlab("Sample Size")+
  theme_bw()+
  theme(legend.position="bottom")  +
  labs(fill="method")+
  labs(shape="Method", fill="Method") + scale_fill_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


figure <- ggarrange(cs_plot_low, rmse_plot_low,
                    #labels = c("        A", "        B"),
                    ncol = 2, nrow = 1, common.legend = TRUE, legend="bottom")

measures_low <- annotate_figure(figure,
                                top = text_grob(paste("Estimated Calibration Slope and RMSPE \n",
                                                      "Prevalence=",toplot$prev[1], ", C-statistic=",toplot$c_true[1], ", N=", N[1]*2,sep=""),
                                                color = "black", face = "bold", size = 13))

#### Measures variability #####

prob_cs <-ddply(toplot, c("epv","method","ms","size"),
                summarise, value = mean(prob_cs,na.rm=TRUE))


rmsd_cs <- ddply(toplot, c("epv","method","ms","size"),
                summarise, value = sqrt(mean(error,na.rm=TRUE)))

rmsdlog_cs <- ddply(toplot, c("epv","method","ms","size"),
                   summarise, value = sqrt(mean(logerror,na.rm=TRUE)))

rmse <-ddply(toplot,c("epv","method","ms"),
             summarise, value = mean(rmse,na.rm=TRUE))

prob_cs_low <- ggplot(prob_cs,
                      aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("Probability of CS in [0.9,1.1]")+ xlab("Sample Size")+
  theme_bw() +
  geom_hline(yintercept = prob_cs$value[19], linetype="dashed",size=1)+
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13))



rmsdlog_cs_low <- ggplot(rmsdlog_cs,
                        aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("RMSD log(Calibration Slope)")+ xlab("Sample size") +
  geom_hline(yintercept = rmsdlog_cs$value[19], linetype="dashed",size=1)+
  theme_bw() +
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13)) +
  scale_x_discrete(expand = c(0.05,0))



figure <- ggarrange(rmsdlog_cs_low, prob_cs_low,
                    #labels = c("        A", "        B"),
                    ncol = 2, nrow = 1, common.legend = TRUE, legend="bottom")

measures_var_low <- annotate_figure(figure,
                                    top = text_grob(paste("Combining bias and variability in the estimated Calibration Slope \n Prevalence=",
                                                          toplot$prev[1], ", C-statistic=",toplot$c_true[1], ", N=",N[1]*2,sep=""),
                                                    color = "black", face = "bold", size = 13))


figure_S1 <- ggarrange(measures_low, measures_var_low, ncol = 1, nrow = 2)
figure_S1 <- measures_var_low 


figure_S1

ggsave("figures_tables/figure_S1.pdf", width=9, height=5)
ggsave("figures_tables/figure_S1.tiff", width=9, height=5, dpi=300)

####################################################################

# Figures S2-S4
# Individual variability plots

# Individual Datasets plots for Figures S1-S3


toplot <-out_p%>% filter(ms==low)%>%filter(epv== unique(out_p$epv)[2]) %>% dplyr::select(-lambda)
# toplot <-na.omit(toplot)
epv <- unique(toplot$epv)

#######

### Calibration Slope

mle_m <- toplot%>%filter(method=="MLE")%>%dplyr::select(slope)
firth_m  <- toplot%>%filter(method=="Firth" )%>%dplyr::select(slope)
boot_unif_m <- toplot%>%filter(method=="Boot-Unif")%>%dplyr::select(slope)
ridge_m  <- toplot%>%filter(method=="Ridge" )%>%dplyr::select(slope)
mod_ridge_m  <- toplot%>%filter(method=="Mod-Ridge" )%>%dplyr::select(slope)
boot_ridge_m  <- toplot%>%filter(method=="Boot-Ridge" )%>%dplyr::select(slope)

lasso_m  <- toplot%>%filter(method=="Lasso" ) %>%dplyr::select(slope)
mod_lasso_m  <- toplot%>%filter(method=="Mod-Lasso" ) %>%dplyr::select(slope)
boot_lasso_m  <- toplot%>%filter(method=="Boot-Lasso" ) %>%dplyr::select(slope)



matrix        <- data.frame(mle_m , firth_m , boot_unif_m , ridge_m , mod_ridge_m, mod_lasso_m, lasso_m )
matrix2      <- matrix


names(matrix) <- c("mle", "firth", "boot_unif", "ridge", "mod_ridge", "mod_lasso", "lasso")


# Baseline MLE

pfirth     = round(mean(ifelse(abs(matrix2[,1]-1)>abs(matrix2[,2]-1),1,0),na.rm=TRUE),2)
pbootunif  = round(mean(ifelse(abs(matrix2[,1]-1)>abs(matrix2[,3]-1),1,0),na.rm=TRUE),2)
pridge     = round(mean(ifelse(abs(matrix2[,1]-1)>abs(matrix2[,4]-1),1,0),na.rm=TRUE),2)
pmodridge  = round(mean(ifelse(abs(matrix2[,1]-1)>abs(matrix2[,5]-1),1,0),na.rm=TRUE),2)
pmodlasso  = round(mean(ifelse(abs(matrix2[,1]-1)>abs(matrix2[,6]-1),1,0),na.rm=TRUE),2)
plasso     = round(mean(ifelse(abs(matrix2[,1]-1)>abs(matrix2[,7]-1),1,0),na.rm=TRUE),2)


pfirth;pbootunif; pridge;pmodridge;pmodlasso; plasso; pmodlasso


min=min(mle_m,firth_m,ridge_m,na.rm=TRUE)
max=max(mle_m,firth_m,ridge_m,na.rm=TRUE)
xlim=c(min,max)
ylim=c(min,max)


firth_plot <- ggplot(matrix, aes(x=mle, y=firth)) +  ylab("Firth")+ ggtitle(pfirth)+ xlab("MLE")+ geom_point() + theme_bw()+ geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

boot_unif_plot <- ggplot(matrix, aes(x=mle, y=boot_unif)) +  ylab("Boot-Unif")+ ggtitle(pbootunif) + xlab("MLE")+ geom_point() + theme_bw()+ geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

mod_ridge_plot <- ggplot(matrix, aes(x=mle, y=mod_ridge)) +  ylab("Mod-Ridge")+ ggtitle(pmodridge) + xlab("MLE")+ geom_point() + theme_bw()+  geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

mod_lasso_plot <- ggplot(matrix, aes(x=mle, y=mod_lasso)) +  ylab("Mod-Lasso")+ ggtitle(pmodlasso) + xlab("MLE")+ geom_point() + theme_bw() + geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

lasso_plot <- ggplot(matrix, aes(x=mle, y=lasso)) +  ylab("Lasso")+ ggtitle(plasso) + xlab("MLE")+ geom_point() + theme_bw() + geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

ridge_plot <- ggplot(matrix, aes(x=mle, y=mod_ridge)) +  ylab("Ridge")+ ggtitle(pridge) + xlab("MLE")+ geom_point() + theme_bw()+  geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))


figure <- ggarrange(firth_plot, boot_unif_plot, ridge_plot, mod_ridge_plot, lasso_plot, mod_lasso_plot,
                    #labels = c("        A", "        B"),
                    ncol = 3, nrow = 2)

figure_S2 <-annotate_figure(figure,
                            top = text_grob(paste("Calibration Slope in individual datasets. Baseline method: MLE \n",
                                                  "Prevalence=", toplot$prev[1], ", C-statistic=",toplot$c_true[1],
                                                  ", N=",N[2], sep=""),
                                            color = "black", face = "bold", size = 11))

figure_S2

ggsave("figures_tables/figure_S2.pdf", width=7.5, height=5)
ggsave("figures_tables/figure_S2.tiff", width=7.5, height=5)

###########################

# C-statistic Scatterplot

mle_m <- toplot%>%filter(method=="MLE")%>%dplyr::select(c_est)
firth_m  <- toplot%>%filter(method=="Firth" )%>%dplyr::select(c_est)
boot_unif_m <- toplot%>%filter(method=="Boot-Unif")%>%dplyr::select(c_est)
ridge_m  <- toplot%>%filter(method=="Ridge" )%>%dplyr::select(c_est)
mod_ridge_m  <- toplot%>%filter(method=="Mod-Ridge" )%>%dplyr::select(c_est)
mod_lasso_m  <- toplot%>%filter(method=="Mod-Lasso" ) %>%dplyr::select(c_est)
lasso_m  <- toplot%>%filter(method=="Lasso" ) %>%dplyr::select(c_est)
boot_ridge_m  <- toplot%>%filter(method=="Boot-Ridge" )%>%dplyr::select(c_est)
boot_lasso_m  <- toplot%>%filter(method=="Boot-Lasso" ) %>%dplyr::select(c_est)

matrix<-data.frame(mle_m , firth_m , boot_unif_m , ridge_m , boot_ridge_m ,boot_lasso_m, lasso_m)
names(matrix)=c("mle", "firth", "boot_unif", "ridge", "mod_ridge", "mod_lasso","lasso")

pfirth=round(mean(ifelse(matrix[,1]>matrix[,2],0,1),na.rm=TRUE),2)
pbootunif=NA
pridge=round(mean(ifelse(matrix[,1]>matrix[,4],0,1),na.rm=TRUE),2)
pmodridge=round(mean(ifelse(matrix[,1]>matrix[,5],0,1),na.rm=TRUE),2)
pmodlasso=round(mean(ifelse(matrix[,1]>matrix[,6],0,1),na.rm=TRUE),2)
plasso=round(mean(ifelse(matrix[,1]>matrix[,7],0,1),na.rm=TRUE),2)

min=min(mle_m,firth_m,ridge_m, mod_ridge_m, mod_lasso_m,na.rm=TRUE)
max=max(mle_m,firth_m,ridge_m, mod_ridge_m, mod_lasso_m,na.rm=TRUE)
xlim=c(min,max)
ylim=c(min,max)


# Base MLE

firth_plot <- ggplot(matrix, aes(x=mle, y=firth)) +  ylab("Firth")+ ggtitle(pfirth)+ xlab("MLE")+ geom_point() + theme_bw()+ geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

boot_unif_plot <- ggplot(matrix, aes(x=mle, y=boot_unif)) +  ylab("Boot-Unif")+ ggtitle(pbootunif) + xlab("MLE")+ geom_point() + theme_bw()+ geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

mod_ridge_plot <- ggplot(matrix, aes(x=mle, y=mod_ridge)) +  ylab("Mod-Ridge")+ ggtitle(pmodridge) + xlab("MLE")+ geom_point() + theme_bw()+  geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

ridge_plot <- ggplot(matrix, aes(x=mle, y=ridge)) +  ylab("Ridge")+ ggtitle(pridge) + xlab("MLE")+ geom_point() + theme_bw()+  geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))


mod_lasso_plot <- ggplot(matrix, aes(x=mle, y=mod_lasso)) +  ylab("Mod-Lasso")+ ggtitle(pmodlasso) + xlab("MLE")+ geom_point() + theme_bw() + geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

lasso_plot <- ggplot(matrix, aes(x=mle, y=lasso)) +  ylab("Lasso")+ ggtitle(plasso) + xlab("MLE")+ geom_point() + theme_bw()+  geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))



figure <- ggarrange(firth_plot, boot_unif_plot, ridge_plot, mod_ridge_plot, lasso_plot,mod_lasso_plot,
                    #labels = c("        A", "        B"),
                    ncol = 3, nrow = 2)

figure_S3 <-annotate_figure(figure,
                            top = text_grob(paste("C-statistic in individual datasets. Baseline method: MLE \n",
                                                  "Prevalence=", toplot$prev[1], ", C-statistic=",toplot$c_true[1], ", N=",N[2], sep=""),
                                            color = "black", face = "bold", size = 11))

figure_S3

ggsave("figures_tables/figure_S3.pdf", width=7.5, height=5)
ggsave("figures_tables/figure_S3.tiff", width=7.5, height=5)

######################################################################

# RPMSE Scatterplot


mle_m <- toplot%>%filter(method=="MLE")%>%dplyr::select(rmse)
firth_m  <- toplot%>%filter(method=="Firth" )%>%dplyr::select(rmse)
boot_unif_m <- toplot%>%filter(method=="Boot-Unif")%>%dplyr::select(rmse)
ridge_m  <- toplot%>%filter(method=="Ridge" )%>%dplyr::select(rmse)
lasso_m  <- toplot%>%filter(method=="Lasso" )%>%dplyr::select(rmse)
mod_ridge_m  <- toplot%>%filter(method=="Mod-Ridge" )%>%dplyr::select(rmse)
boot_ridge_m  <- toplot%>%filter(method=="Boot-Ridge" )%>%dplyr::select(rmse)
mod_lasso_m  <- toplot%>%filter(method=="Mod-Lasso" ) %>%dplyr::select(rmse)
boot_lasso_m  <- toplot%>%filter(method=="Boot-Lasso" ) %>%dplyr::select(rmse)



matrix<-data.frame(mle_m , firth_m , boot_unif_m, ridge_m, mod_ridge_m ,lasso_m, mod_lasso_m )
names(matrix)=c("mle", "firth", "boot_unif", "ridge", "mod_ridge", "lasso","mod_lasso")


pfirth      = round(mean(ifelse(matrix[,1]>matrix[,2],1,0),na.rm=TRUE),2)
pbootunif   = round(mean(ifelse(matrix[,1]>matrix[,3],1,0),na.rm=TRUE),2)
pridge      = round(mean(ifelse(matrix[,1]>matrix[,4],1,0),na.rm=TRUE),2)
pmodridge  = round(mean(ifelse(matrix[,1]>matrix[,5],1,0),na.rm=TRUE),2)
plasso      = round(mean(ifelse(matrix[,1]>matrix[,6],1,0),na.rm=TRUE),2)
pmodlasso  = round(mean(ifelse(matrix[,1]>matrix[,7],1,0),na.rm=TRUE),2)


min=min(mle_m,firth_m,ridge_m,na.rm=TRUE)
max=max(mle_m,firth_m,ridge_m,na.rm=TRUE)
xlim=c(min,max)
ylim=c(min,max)


# Base MLE

firth_plot <- ggplot(matrix, aes(x=mle, y=firth)) +  ylab("Firth")+ ggtitle(pfirth)+ xlab("MLE")+ geom_point() + theme_bw()+ geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

boot_unif_plot <- ggplot(matrix, aes(x=mle, y=boot_unif)) +  ylab("Boot-Unif")+ ggtitle(pbootunif) + xlab("MLE")+ geom_point() + theme_bw()+ geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

ridge_plot <- ggplot(matrix, aes(x=mle, y=ridge)) +  ylab("Ridge")+ ggtitle(pridge) + xlab("MLE")+ geom_point() + theme_bw()+  geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

mod_ridge_plot <- ggplot(matrix, aes(x=mle, y=mod_ridge)) +  ylab("Mod-Ridge")+ ggtitle(pmodridge) + xlab("MLE")+ geom_point() + theme_bw()+  geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

mod_lasso_plot <- ggplot(matrix, aes(x=mle, y=mod_lasso)) +  ylab("Mod-Lasso")+ ggtitle(pmodlasso) + xlab("MLE")+ geom_point() + theme_bw() + geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))

lasso_plot <- ggplot(matrix, aes(x=mle, y=lasso)) +  ylab("Lasso")+ ggtitle(plasso) + xlab("MLE")+ geom_point() + theme_bw() + geom_abline(intercept = 0, slope=1) +
  scale_y_continuous(limits = c(xlim, ylim)) + scale_x_continuous(limits = c(xlim, ylim)) + theme(plot.title = element_text(hjust = 0.5))


figure <- ggarrange(firth_plot, boot_unif_plot, ridge_plot, mod_ridge_plot, lasso_plot, mod_lasso_plot,
                    #labels = c("        A", "        B"),
                    ncol = 3, nrow = 2)

figure_S4 <-annotate_figure(figure,
                            top = text_grob(paste("RMSPE in individual datasets. Baseline method: MLE \n",
                                                  "Prevalence=", toplot$prev[1], ", C-statistic=",toplot$c_true[1], ", N=",N[2], sep=""),
                                            color = "black", face = "bold", size = 11))

figure_S4

ggsave("figures_tables/figure_S4.pdf" , width=6.5, height=5)
ggsave("figures_tables/figure_S4.tiff", width=6.5, height=5)

#########################################################################

## Figure S5
## High Model Strength

load("intermediate_results/penalised_p_05.Rdata")


out_p$method = factor(out_p$method)
levels(out_p$method) = c("MLE", "Firth","Boot-Unif", "Heur-Unif", "Ridge", "Mod-Ridge", "Boot-Ridge", "Lasso", "Mod-Lasso", "Boot-Lasso")

myColors <- brewer.pal(10, "Spectral")
names(myColors) <- levels(out_p$method)
custom_colors <- scale_colour_manual(name = "Method", values = myColors)


out_p$ms = factor(out_p$c_true)

low    <- paste("C=",round(inputs$c_true[1],2));
high   <- paste("C=",round(inputs$c_true[2],2));

out_p$ms<- low
out_p$ms[out_p$strength==inputs$strength[2]]<-high
out_p$ms <- factor(out_p$ms, levels=c(low, high))

k <- 2

toplot <-out_p%>%
  filter(ms==high)%>%
  filter(method!="Heur-Unif" & method!="Mod-Lasso" & method !="Mod-Ridge")


toplot$slope[toplot$slope<0] <- 0.1
toplot$slope[toplot$slope>10] <- 10

N   <- unique(toplot$epv)*n.predictors/prev
N   <- round(N/10)*10

toplot$size = factor(toplot$epv)
levels(toplot$size) = c("N/2", "3N/4", "N", "5N/4")


epv <- round(unique(toplot$epv),1)

toplot$prob_cs  <- ifelse(toplot$slope>=0.9 & toplot$slope<=1.1,1,0)
toplot$error    <- (1-toplot$slope)^2
toplot$logerror    <- (log(1)-log(toplot$slope))^2


toplot <- toplot %>% dplyr::select(-lambda)
toplot <-na.omit(toplot)


scale_fill_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'fill',
    values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}

scale_col_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'col',
    values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}



# Calibration slope

cs_plot_high <- ggplot(toplot,
                      aes(x=size, y=slope, fill=method)) +
  geom_hline(yintercept=1,linetype="dashed") +
  geom_boxplot() + ylab("Calibration Slope (log-scale)")+ xlab("Sample size")+
  theme_bw()+
  theme(legend.position="bottom")+
  scale_y_continuous(limits = c(0.5, 2.5), breaks=c(0.5, 0.7, 0.9, 1, 1.1, 1.5, 2, 2.5), trans='log10') +
  labs(shape="Method", colour="Method") + scale_fill_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


cstat_plot_high <- ggplot(toplot,
                         aes(x=size, y=c_est, fill=method)) +
  geom_boxplot()  + ylab("C-statistic")+ xlab("EPV")+
  theme_bw()+
  theme(legend.position="bottom") + scale_fill_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


rmse_plot_high <- ggplot(toplot,
                          aes(x=size, y=brier, fill=method)) +
  geom_boxplot() + ylab("RMSPE")+ xlab("EPV")+
  theme_bw()+
  theme(legend.position="bottom") + scale_fill_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


figure <- ggarrange(cs_plot_high, cstat_plot_high, rmse_plot_high,
                    ncol = 3, nrow = 1, common.legend = TRUE, legend="bottom")

measures_high <- annotate_figure(figure,
                               top = text_grob(paste("Estimated Calibration Slope,  C-statistic and Brier Score \n",
                                                     "Prevalence=",toplot$prev[1], ", C=",toplot$c_true[1],", N=",N[1]*2, sep=""),
                                               color = "black", face = "bold", size = 13))

#### Measures variability #####

prob_cs <-ddply(toplot, c("epv","method","ms", "size"),
                summarise, value = mean(prob_cs,na.rm=TRUE))


rmsd_cs <-ddply(toplot,c("epv","method","ms", "size"),
                summarise, value = sqrt(mean(error,na.rm=TRUE)))

rmsdlog_cs <-ddply(toplot,c("epv","method","ms","size"),
                   summarise, value = sqrt(mean(logerror,na.rm=TRUE)))

rmse <-ddply(toplot,c("epv","method","ms", "size"),
             summarise, value = mean(rmse,na.rm=TRUE))

prob_cs_high <- ggplot(prob_cs,
                      aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("Probability of CS in [0.9,1.1]")+ xlab("Sample Size")+
  theme_bw() +
  geom_hline(yintercept = prob_cs$value[15], linetype="dashed",size=1)+
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13)) +
  scale_x_discrete(expand = c(0.05,0))


rmse_high <- ggplot(rmse,
                   aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("RMSPE")+ xlab("Sample size") +
  geom_hline(yintercept = rmse$value[15], linetype="dashed",size=1)+
  theme_bw() +
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13))

rmsdlog_cs_high <- ggplot(rmsdlog_cs,
                        aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("RMSD log(Calibration Slope)")+ xlab("Sample size") +
  geom_hline(yintercept = rmsdlog_cs$value[15], linetype="dashed",size=1)+
  theme_bw() +
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13)) +
  scale_x_discrete(expand = c(0.05,0))


rmsd_cs_high<- ggplot(rmsd_cs,
                      aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("RMSD Calibration Slope")+ xlab("Sample size") +
  geom_hline(yintercept = rmsd_cs$value[15], linetype="dashed",size=1)+
  theme_bw() +   labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method") + scale_col_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


figure <- ggarrange(rmsdlog_cs_high, prob_cs_high,
                    #labels = c("        A", "        B"),
                    ncol = 2, nrow = 1, common.legend = TRUE, legend="bottom")

measures_var_high <- annotate_figure(figure,
                                   top = text_grob(paste("Combining bias and variability in the estimated Calibration Slope \n Prevalence=",
                                                         toplot$prev[1], ", C-statistic=",toplot$c_true[1], ", N=",N[1]*2, sep=""),
                                                   color = "black", face = "bold", size = 13))

figure_S5 <- measures_var_high
figure_S5


ggsave("figures_tables/figure_S5.pdf" , width=9, heigh=5)
ggsave("figures_tables/figure_S5.tiff", width=9, heigh=5)

#####################################################################

### Figure S6  ###

# Prevalence = 0.1

# Low Model Strength: C=0.7

load("intermediate_results/penalised_p_01.Rdata")


out_p$method = factor(out_p$method)
levels(out_p$method) = c("MLE", "Firth","Boot-Unif", "Heur-Unif", "Ridge", "Mod-Ridge", "Boot-Ridge", "Lasso", "Mod-Lasso", "Boot-Lasso")

myColors <- brewer.pal(10, "Spectral")
names(myColors) <- levels(out_p$method)
custom_colors <- scale_colour_manual(name = "Method", values = myColors)

scale_fill_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'fill',
    values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}

scale_col_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'col',
    values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}

out_p$ms = factor(out_p$c_true)

low    <- paste("C=",round(inputs$c_true[1],2));
high   <- paste("C=",round(inputs$c_true[2],2));

out_p$ms<- low
out_p$ms[out_p$strength==inputs$strength[2]]<-high
out_p$ms <- factor(out_p$ms, levels=c(low, high))

k <- 1

toplot <-out_p%>%
  filter(ms==low)%>%
  filter(method!="Heur-Unif" & method!="Mod-Lasso" & method !="Mod-Ridge")

toplot$slope[toplot$slope<0] <- 0.1
toplot$slope[toplot$slope>10] <- 10


toplot$size = factor(toplot$epv)
levels(toplot$size) = c("N/2", "3N/4", "N", "5N/4")


epv <- round(unique(toplot$epv),1)

N   <- unique(toplot$epv)*n.predictors/prev
N   <- round(N/10)*10

toplot$prob_cs  <- ifelse(toplot$slope>=0.9 & toplot$slope<=1.1,1,0)
toplot$error    <- (1-toplot$slope)^2
toplot$logerror    <- (log(1)-log(toplot$slope))^2


toplot <- toplot %>% dplyr::select(-lambda)
toplot <-na.omit(toplot)




# Calibration slope

cs_plot_low <- ggplot(toplot,
                      aes(x=size, y=slope, fill=method)) +
  geom_hline(yintercept=1,linetype="dashed") +
  geom_boxplot() + ylab("Calibration Slope (log-scale)") + xlab("Sample Size") +
  theme_bw()+
  theme(legend.position="bottom")+
  scale_y_continuous(breaks=c(0,0.5,0.8, 0.9,1,1.1,1.5,2.5), limits = c(0.5, 2.5),trans="log10") +
  labs(fill="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", fill="Method") + scale_fill_shrinkage() +
  guides(color=guide_legend(nrow=2, byrow=FALSE)) +
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


cstat_plot_low <- ggplot(toplot,
                         aes(x=size, y=c_est, fill=method)) +
  geom_boxplot()  + ylab("C-statistic")+ xlab("EPV")+
  theme_bw()+
  theme(legend.position="bottom")  +
  labs(fill="method")+
  labs(shape="Method", fill="Method") + scale_fill_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


rmse_plot_low <- ggplot(toplot, aes(x=size, y=rmse, fill=method)) +
  geom_boxplot() + ylab("RMSPE")+ xlab("EPV")+
  theme_bw()+
  theme(legend.position="bottom")  +
  labs(fill="method")+
  labs(shape="Method", fill="Method") + scale_fill_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13))



figure <- ggarrange(cs_plot_low, cstat_plot_low, rmse_plot_low,
                    #labels = c("        A", "        B"),
                    ncol = 3, nrow = 1, common.legend = TRUE, legend="bottom")

measures_low <- annotate_figure(figure,
                                top = text_grob(paste("Calibration Slope, C-statistic and Root Mean Square Prediction Error (RMSPE) \n",
                                                      "Prevalence=",toplot$prev[1], ", C=",toplot$c_true[1],
                                                      ", N=",N[1]*2,sep=""),
                                                color = "black", face = "bold", size = 13))


figure <- ggarrange(cs_plot_low, cstat_plot_low, rmse_plot_low,
                    ncol = 3, nrow = 1, common.legend = TRUE, legend="bottom")

measures_low <- annotate_figure(figure,
                                  top = text_grob(paste("Estimated Calibration Slope,  C-statistic and Brier Score \n",
                                                        "Prevalence=",toplot$prev[1], ", C=",toplot$c_true[1],", N=",N[1]*2, sep=""),
                                                  color = "black", face = "bold", size = 13))


#### Measures variability #####

prob_cs <-ddply(toplot, c("epv","method","ms","size"),
                summarise, value = mean(prob_cs,na.rm=TRUE))


rmsd_cs <- ddply(toplot, c("epv","method","ms","size"),
                 summarise, value = sqrt(mean(error,na.rm=TRUE)))

rmsdlog_cs <- ddply(toplot, c("epv","method","ms","size"),
                    summarise, value = sqrt(mean(logerror,na.rm=TRUE)))

rmse <-ddply(toplot,c("epv","method","ms","size"),
             summarise, value = mean(rmse,na.rm=TRUE))

prob_cs_low <- ggplot(prob_cs,
                      aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("Probability of CS in [0.9,1.1]")+ xlab("Sample Size")+
  theme_bw() +
  geom_hline(yintercept = prob_cs$value[15], linetype="dashed",size=1)+
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


prob_cs_low


rmsdlog_cs_low <- ggplot(rmsdlog_cs,
                         aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("RMSD log(Calibration Slope)")+ xlab("Sample size") +
  geom_hline(yintercept = rmsdlog_cs$value[15], linetype="dashed",size=1)+
  theme_bw() +
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13)) +
  scale_x_discrete(expand = c(0.05,0))


rmsdlog_cs_low

figure <- ggarrange(rmsdlog_cs_low, prob_cs_low,
                    #labels = c("        A", "        B"),
                    ncol = 2, nrow = 1, common.legend = TRUE, legend="bottom")

measures_var_low <- annotate_figure(figure,
                                    top = text_grob(paste("Combining bias and variability in the estimated Calibration Slope \n Prevalence=",
                                                          toplot$prev[1], ", C-statistic=",toplot$c_true[1], ", N=",N[1]*2,sep=""),
                                                    color = "black", face = "bold", size = 13))

figure_S6 <- measures_var_low
figure_S6


ggsave("figures_tables/figure_S6.pdf", width=9, heigh=5)
ggsave("figures_tables/figure_S6.tiff", width=9, heigh=5)

#####################################################################

## Figure S7
## High Model Strength: C=0.8

load("intermediate_results/penalised_p_01.Rdata")


out_p$method = factor(out_p$method)
levels(out_p$method) = c("MLE", "Firth","Boot-Unif", "Heur-Unif", "Ridge", "Mod-Ridge", "Boot-Ridge", "Lasso", "Mod-Lasso", "Boot-Lasso")

myColors <- brewer.pal(10, "Spectral")
names(myColors) <- levels(out_p$method)
custom_colors <- scale_colour_manual(name = "Method", values = myColors)

scale_fill_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'fill',
    values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}

scale_col_shrinkage <- function(...){
  ggplot2:::manual_scale(
    'col',
    values = setNames(hue_pal()(10), levels(out_p$method)), drop=TRUE, limits=force,
    ...
  )
}



out_p$ms = factor(out_p$c_true)

low    <- paste("C=",round(inputs$c_true[1],2));
high   <- paste("C=",round(inputs$c_true[2],2));

out_p$ms<- low
out_p$ms[out_p$strength==inputs$strength[2]]<-high
out_p$ms <- factor(out_p$ms, levels=c(low, high))

k <- 2

toplot <-out_p%>%
  filter(ms==high)%>%
  filter(method!="Heur-Unif" & method!="Mod-Lasso" & method !="Mod-Ridge")

toplot$slope[toplot$slope<0] <- 0.1
toplot$slope[toplot$slope>10] <- 10

toplot$size = factor(toplot$epv)
levels(toplot$size) = c("N/2", "3N/4", "N", "5N/4")


epv <- round(unique(toplot$epv),1)

N   <- unique(toplot$epv)*n.predictors/prev
N   <- round(N/10)*10

toplot$prob_cs  <- ifelse(toplot$slope>=0.9 & toplot$slope<=1.1,1,0)
toplot$error    <- (1-toplot$slope)^2
toplot$logerror    <- (log(1)-log(toplot$slope))^2


toplot <- toplot %>% dplyr::select(-lambda)
toplot <-na.omit(toplot)



# Calibration slope

cs_plot_high <- ggplot(toplot,
                       aes(x=size, y=slope, fill=method)) +
  geom_hline(yintercept=1,linetype="dashed") +
  geom_boxplot() + ylab("Calibration Slope (log-scale)")+ xlab("Sample size")+
  theme_bw()+
  theme(legend.position="bottom")+
  scale_y_continuous(limits = c(0.5, 2.5), breaks=c(0.5, 0.7, 0.9, 1, 1.1, 1.5, 2, 2.5), trans='log10') +
  labs(shape="Method", colour="Method") + scale_fill_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


cstat_plot_high <- ggplot(toplot,
                          aes(x=size, y=c_est, fill=method)) +
  geom_boxplot()  + ylab("C-statistic")+ xlab("EPV")+
  theme_bw()+
  theme(legend.position="bottom") + scale_fill_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


rmse_plot_high <- ggplot(toplot,
                         aes(x=size, y=brier, fill=method)) +
  geom_boxplot() + ylab("RMSPE")+ xlab("EPV")+
  theme_bw()+
  theme(legend.position="bottom") + scale_fill_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13))


figure <- ggarrange(cs_plot_high, cstat_plot_high, rmse_plot_high,
                    ncol = 3, nrow = 1, common.legend = TRUE, legend="bottom")

measures_high <- annotate_figure(figure,
                                 top = text_grob(paste("Estimated Calibration Slope,  C-statistic and Brier Score \n",
                                                       "Prevalence=",toplot$prev[1], ", C=",toplot$c_true[1]," N=",N[1]*2, sep=""),
                                                 color = "black", face = "bold", size = 13))

#### Measures variability #####

prob_cs <-ddply(toplot, c("epv","method","ms", "size"),
                summarise, value = mean(prob_cs,na.rm=TRUE))


rmsd_cs <-ddply(toplot,c("epv","method","ms", "size"),
                summarise, value = sqrt(mean(error,na.rm=TRUE)))

rmsdlog_cs <-ddply(toplot,c("epv","method","ms","size"),
                   summarise, value = sqrt(mean(logerror,na.rm=TRUE)))

rmse <-ddply(toplot,c("epv","method","ms", "size"),
             summarise, value = mean(rmse,na.rm=TRUE))

prob_cs_high <- ggplot(prob_cs,
                       aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("Probability of CS in [0.9,1.1]")+ xlab("Sample Size")+
  theme_bw() +
  geom_hline(yintercept = prob_cs$value[15], linetype="dashed",size=1)+
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13))  +
  scale_x_discrete(expand = c(0.05,0))


rmsdlog_cs_high <- ggplot(rmsdlog_cs,
                          aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("RMSD log(Calibration Slope)")+ xlab("Sample size") +
  geom_hline(yintercept = rmsdlog_cs$value[15], linetype="dashed",size=1)+
  theme_bw() +
  labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method")+ scale_col_shrinkage()+
  ggplot2::theme(text =  ggplot2::element_text(size = 13)) +
  scale_x_discrete(expand = c(0.05,0))


rmsd_cs_high<- ggplot(rmsd_cs,
                      aes(x=size, y=value, group=method, col=method)) +
  geom_line(size=1) +
  ylab("RMSD Calibration Slope")+ xlab("Sample size") +
  geom_hline(yintercept = rmsd_cs$value[15], linetype="dashed",size=1)+
  theme_bw() +   labs(colour="method")+
  theme(legend.position="bottom") +
  labs(shape="Method", colour="Method") + scale_col_shrinkage() +
  ggplot2::theme(text =  ggplot2::element_text(size = 13))




figure <- ggarrange(rmsdlog_cs_high, prob_cs_high,
                    #labels = c("        A", "        B"),
                    ncol = 2, nrow = 1, common.legend = TRUE, legend="bottom")

measures_var_high <- annotate_figure(figure,
                                     top = text_grob(paste("Combining bias and variability in the estimated Calibration Slope \n Prevalence=",toplot$prev[1],
                                                           ", C-statistic=",toplot$c_true[1],", N=",N[1]*2, sep=""),
                                                     color = "black", face = "bold", size = 13))

figure_S7 <- measures_var_high
figure_S7

ggsave("figures_tables/figure_S7.pdf",width=9, heigh=5)
ggsave("figures_tables/figure_S7.tiff",width=9, heigh=5)

###############################################################################################################################################################
