

`%dopar%` <- foreach::`%dopar%`
`%do%` <- foreach::`%do%`

all_methods <- foreach(i=1:nsim, .combine='rbind', .packages=c('foreach', 'MASS','RcppNumerical', 'pROC', 'brglm2', 'detectseparation','RcppNumerical', 'logistf', 'glmnet')) %dopar% {

   # cat(paste("\n","Iteration, kfold ",c(i),"\n"),
   #     file="log.txt", append=TRUE)

    set.seed(i+1000)
    
    # Validation
    DATA.VAL <- generate_data(NN = 50000, n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors,beta.0 = inputs$beta.0[k] , strength=strength, cor0=0.1, cor1=0.05)

    # Development
    DATA <- generate_data(NN = N[j], n.true.predictors = n.true.predictors, n.noise.predictors = n.noise.predictors, beta.0 = inputs$beta.0[k], strength=strength, cor0=0.1, cor1=0.05)

    # Development
    x          = as.matrix(DATA[,1:(n.true.predictors+n.noise.predictors)])
    y          = DATA$y

    # Validation
    xval          = as.matrix(DATA.VAL[,1:(n.true.predictors+n.noise.predictors)])
    yval          = DATA.VAL$y


    # MLE
    ### fit maximum likelihood full model
    fit <- withwarnings(glm(y ~ ., data = DATA, family = 'binomial'))

    if (length(fit$value)!=0) {

      fit     <- fit$value
      beta    <- coef(fit)
      betain  <- beta
      mle     <- c(prev, strength, ctrue[k], epv[j], 0, NA, measures(yval, xval, beta, beta.true))


      # Important: set to right values
      nfolds  <- 10

      set.seed(i)
      #  ridge 5 fold
      fit     <- cv.glmnet(x=x, y=y,  alpha = 0, family = 'binomial',  nfolds = nfolds, type.measure = 'deviance',parallel=T)
      beta    <- as.vector(coef(fit,s="lambda.min"))
      lambda  <- fit$lambda.min
      ridge5  <- c(prev, strength, ctrue[k], epv[j], 1, lambda, measures(yval, xval, beta, beta.true))

      # ridge 10 fold
      set.seed(i)

      fit     <- cv.glmnet(x=x, y=y,  alpha = 0, family = 'binomial',  nfolds = 10, type.measure = 'deviance',parallel=T)
      beta    <- as.vector(coef(fit,s="lambda.min"))
      lambda  <- fit$lambda.min
      ridge10 <- c(prev, strength, ctrue[k], epv[j], 2, lambda, measures(yval, xval, beta, beta.true))

      # ridge 20 fold

      fit      <- cv.glmnet(x=x, y=y,  alpha = 0, family = 'binomial',  nfolds = 20, type.measure = 'deviance',parallel=T)
      beta     <- as.vector(coef(fit,s="lambda.min"));
      lambda   <- fit$lambda.min
      ridge20  <- c(prev, strength, ctrue[k], epv[j], 3, lambda, measures(yval, xval, beta, beta.true))


      #n-fold
      fit      <- cv.glmnet(x=x, y=y,  alpha = 0, family = 'binomial',  nfolds = N[j], type.measure = 'deviance',parallel=T)
      beta     <- as.vector(coef(fit,s="lambda.min"));
      lambda   <- fit$lambda.min
      ridgen   <- c(prev, strength, ctrue[k], epv[j], 4, lambda, measures(yval, xval, beta, beta.true))


      # Mod-Ridge
      set.seed(i)
      a               <-  mod_penal_ave_foreach(x=x, y=y, method="ridge", bn=bn, nfolds=nfolds, boot=TRUE)
      lambda          <-  a$lambda.boot
      beta            <-  a$beta.boot
      boot.ridge      <- c(prev, strength, ctrue[k], epv[j], 5, lambda, measures(yval, xval, beta, beta.true))


      # Boot Ridge
      set.seed(i)
      a               <-  boot_penal_foreach(x=x, y=y, method="ridge", bn=bn)
      lambda          <-  a$lambda.boot
      beta            <-  a$beta.boot
      boot.ridge1     <-  c(prev, strength, ctrue[k], epv[j], 6, lambda, measures(yval, xval, beta, beta.true))

      # Lasso

      # Lasso 5 fold
      fit     <- cv.glmnet(x=x, y=y,  alpha = 1, family = 'binomial',  nfolds = 5, type.measure = 'deviance', parallel=T)
      beta    <- as.vector(coef(fit,s="lambda.min"));lambda<-fit$lambda.min
      lasso5  <- c(prev, strength, ctrue[k], epv[j], 7, lambda, measures(yval, xval, beta, beta.true))


      # Lasso 10 fold
      set.seed(i)
      fit      <- cv.glmnet(x=x, y=y,  alpha = 1, family = 'binomial',  nfolds = 10, type.measure = 'deviance', parallel=T)
      beta     <- as.vector(coef(fit,s="lambda.min"));lambda<-fit$lambda.min
      lasso10  <- c(prev, strength, ctrue[k], epv[j], 8, lambda, measures(yval, xval, beta, beta.true))


      # Lasso 20 fold

      fit      <- cv.glmnet(x=x, y=y,  alpha = 1, family = 'binomial',  nfolds = 20, type.measure = 'deviance', parallel=T)
      beta     <- as.vector(coef(fit,s="lambda.min"));lambda<-fit$lambda.min
      lasso20  <- c(prev, strength, ctrue[k], epv[j], 9, lambda, measures(yval, xval, beta, beta.true))

      # Lasso n-fold
      fit      <- cv.glmnet(x=x, y=y,  alpha = 1, family = 'binomial',  nfolds = N[j], type.measure = 'deviance', parallel=T)
      beta     <- as.vector(coef(fit,s="lambda.min"));lambda<-fit$lambda.min
      lasson   <- c(prev, strength, ctrue[k], epv[j], 10, lambda, measures(yval, xval, beta, beta.true))

      # Modified-Lasso
      set.seed(i)
      a               <-  mod_penal_ave_foreach(x=x, y=y, method="lasso", bn=bn, nfolds=nfolds, boot=TRUE)
      lambda          <-  a$lambda.boot
      beta            <-  a$beta.boot
      boot.lasso      <- c(prev, strength, ctrue[k], epv[j], 11, lambda, measures(yval, xval, beta, beta.true))

      # Boot-Lasso
      set.seed(i)
      a               <-  boot_penal_foreach(x=x, y=y, method="lasso", bn=bn)
      lambda          <-  a$lambda.boot
      beta            <-  a$beta.boot
      boot.lasso1     <-  c(prev, strength, ctrue[k], epv[j], 12, lambda, measures(yval, xval, beta, beta.true))


      # Remove some of the methods from running

      # ridge5   <- c(prev, strength, ctrue[k], epv[j], 1, NA, rep(NA,4))
      # ridge10  <- c(prev, strength, ctrue[k], epv[j], 2, NA, rep(NA,4))
      # ridge20   <- c(prev, strength, ctrue[k], epv[j], 3, NA, rep(NA,4))
      # ridgen  <- c(prev, strength, ctrue[k], epv[j], 4, NA, rep(NA,4))
      # boot.ridge<- c(prev, strength, ctrue[k], epv[j], 6, NA, rep(NA,4))
      # boot.ridge1<- c(prev, strength, ctrue[k], epv[j], 6, NA, rep(NA,4))
      # lasso5  <- c(prev, strength, ctrue[k], epv[j], 7, NA, rep(NA,4))
      # lasso10  <- c(prev, strength, ctrue[k], epv[j], 8, NA, rep(NA,4))
      # lasso20 <- c(prev, strength, ctrue[k], epv[j], 9, NA, rep(NA,4))
      # lasson  <- c(prev, strength, ctrue[k], epv[j], 10, NA, rep(NA,4))
      # boot.lasso<- c(prev, strength, ctrue[k], epv[j], 11, NA, rep(NA,4))
      # boot.lasso1<- c(prev, strength, ctrue[k], epv[j], 12, NA, rep(NA,4))

    } else {

      mle         <- c(prev, strength, ctrue[k], epv[j], 0, NA, rep(NA,4))
      ridge5      <- c(prev, strength, ctrue[k], epv[j], 1, NA, rep(NA,4))
      ridge10     <- c(prev, strength, ctrue[k], epv[j], 2, NA, rep(NA,4))
      ridge20     <- c(prev, strength, ctrue[k], epv[j], 3, NA, rep(NA,4))
      ridgen      <- c(prev, strength, ctrue[k], epv[j], 4, NA, rep(NA,4))
      boot.ridge  <- c(prev, strength, ctrue[k], epv[j], 5, NA, rep(NA,4))
      boot.ridge1 <- c(prev, strength, ctrue[k], epv[j], 6, NA, rep(NA,4))

      lasso5      <- c(prev, strength, ctrue[k], epv[j], 7, NA, rep(NA,4))
      lasso10     <- c(prev, strength, ctrue[k], epv[j], 8, NA, rep(NA,4))
      lasso20     <- c(prev, strength, ctrue[k], epv[j], 9, NA, rep(NA,4))
      lasson      <- c(prev, strength, ctrue[k], epv[j], 10, NA, rep(NA,4))
      boot.lasso  <- c(prev, strength, ctrue[k], epv[j], 11, NA, rep(NA,4))
      boot.lasso1 <- c(prev, strength, ctrue[k], epv[j], 12, NA, rep(NA,4))

    }


    rbind(mle, ridge5, ridge10, ridge20, ridgen, boot.ridge, boot.ridge1, lasso5, lasso10, lasso20, lasson, boot.lasso, boot.lasso1)
}
