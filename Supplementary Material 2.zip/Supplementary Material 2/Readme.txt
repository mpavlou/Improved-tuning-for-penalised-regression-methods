Supplementary information and reproducible research files for the manuscript
 
" Penalised regression methods with modified cross-validation or boostrap 
  tuning produce better prediction models"

Authors: Pavlou, M., Ambler G., Omar, R. Z.

-------------------------------------------

Code was written by Pavlou, M. 

Version information for the software (operating system, statistical libraries 
and add-on packages) can be found in the end of this document.

For any questions please contact m.pavlou@ucl.ac.uk

#####################################################################################

R files included
---------------

1. sim_1.R
2. sim_1_methods.R
3. sim_1_plots.R
4. sim_2.R
5. sim_2_methods.R
6. sim_2_plots.R
7. sim_3_example_synthetic_data.R
8. sim_3_example_synthetic_data_plots.R
9. paper_functions.R


Files 1-8 include the code to perform the simulations and reproduce all figures
in the main paper and Supplementary material 1. 

File 9 contains the necessary functions to fit the models for the methods used 
in the simulations.

Note: The simulation studies and computationally very expensive taking many hours 
      to run on a standard computer

- We describe below how to reproduce figures using the data generated from the  
  simulations and stored in folder 'intermediate_results'

- To reduce simulation time, change the number of repetitions, number of boostrap
  iterations and size of validation as instructed in lines 29-34 in each of the 
  files: sim1.R, sim2.R and sim_3_example_synthetic_data.R

#####################################################################################

Instructions to run the simulation and produce the Figures in the Main paper and 
Supplementary Material 1
----------------------------------------------------------------------------------
  
Step 1) Open file 'sim_1.R' and run the entire file.

        This produces Figures 1-2 and saves them in folder 'figures_tables'.

        It also saves the simulation data needed to produce the figures in 
        the folder 'intermediate_results'.

        Note: It takes several hours to run this simulation. To obtain the figures 
        using the intermediate results open and run the file 'sim_1_plots'.

--------
        
Step 2) Open file 'sim_2.R' and run the entire file.

        Produces Figures 3-4 & S1-S7 and saves them in folder 'figures_tables'

        It also saves the simulation data needed to produce the figures in 
        the folder 'intermediate_results'

        Note: It takes several hours to run this simulation. To obtain the figures 
        using the intermediate results, open and run the file 'sim_2_plots'.

--------

Step 3) Open file 'sim_3_example_synthetic_data' and run the entire file.

        First generates synthetic data similar to the real data example.
 
        Then produces Figures S9-S10 (analogous to Figure 5 and S8).

        It also saves the simulation data needed to produce the figures in 
        the folder 'intermediate_results'.

        Note: It takes several hours to run this simulation. To obtain 
        the figures using the intermediate results open and run the file
        'sim_3_example_synthetic_data_plots'.

#####################################################################################

The code was written/evaluated in R with the following software versions:
R version 4.0.5 (2021-03-31)
Platform: x86_64-w64-mingw32/x64 (64-bit)
Running under: Windows 10 x64 (build 19045)

Matrix products: default

locale:
[1] LC_COLLATE=English_United Kingdom.1252  LC_CTYPE=English_United Kingdom.1252   
[3] LC_MONETARY=English_United Kingdom.1252 LC_NUMERIC=C                           
[5] LC_TIME=English_United Kingdom.1252    

attached base packages:
[1] parallel  stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
 [1] vtable_1.4.3         kableExtra_1.3.4     detectseparation_0.3 brglm2_0.9          
 [5] RcppNumerical_0.5-0  predtools_0.0.2      pROC_1.18.0          pmsampsize_1.1.2    
 [9] logistf_1.24.1       speedglm_0.3-4       rms_6.3-0            SparseM_1.81        
[13] Hmisc_4.7-1          Formula_1.2-4        survival_3.2-10      lattice_0.20-41     
[17] glmnet_4.1-4         Matrix_1.5-1         doParallel_1.0.17    iterators_1.0.14    
[21] foreach_1.5.2        openxlsx_4.2.5.1     RColorBrewer_1.1-3   scales_1.2.1        
[25] GGally_2.1.2         plotly_4.10.0        ggpubr_0.4.0         DescTools_0.99.48   
[29] blorr_0.3.0          plyr_1.8.7           patchwork_1.1.2      lubridate_1.9.0     
[33] timechange_0.1.1     forcats_1.0.0        stringr_1.5.0        dplyr_1.1.3         
[37] purrr_1.0.2          readr_2.1.3          tidyr_1.2.1          tibble_3.2.1        
[41] ggplot2_3.3.6        tidyverse_2.0.0      MASS_7.3-53.1       

loaded via a namespace (and not attached):
  [1] readxl_1.4.1             backports_1.4.1          systemfonts_1.0.4       
  [4] lazyeval_0.2.2           splines_4.0.5            operator.tools_1.6.3    
  [7] TH.data_1.1-1            digest_0.6.30            htmltools_0.5.5         
 [10] fansi_1.0.3              magrittr_2.0.3           checkmate_2.1.0         
 [13] enrichwith_0.3.1         cluster_2.1.1            tzdb_0.4.0              
 [16] formula.tools_1.7.1      svglite_2.1.1            sandwich_3.0-2          
 [19] jpeg_0.1-9               colorspace_2.0-3         rvest_1.0.3             
 [22] textshaping_0.3.6        xfun_0.34                jsonlite_1.8.3          
 [25] Exact_3.2                zoo_1.8-11               glue_1.6.2              
 [28] registry_0.5-1           gtable_0.3.1             webshot_0.5.4           
 [31] MatrixModels_0.5-1       car_3.1-1                shape_1.4.6             
 [34] abind_1.4-5              mvtnorm_1.1-3            rstatix_0.7.2           
 [37] Rcpp_1.0.9               viridisLite_0.4.1        htmlTable_2.4.1         
 [40] foreign_0.8-81           proxy_0.4-27             htmlwidgets_1.6.2       
 [43] httr_1.4.4               ellipsis_0.3.2           mice_3.14.0             
 [46] pkgconfig_2.0.3          reshape_0.8.9            farver_2.1.1            
 [49] nnet_7.3-15              deldir_1.0-6             utf8_1.2.2              
 [52] tidyselect_1.2.0         labeling_0.4.2           rlang_1.1.2             
 [55] munsell_0.5.0            cellranger_1.1.0         tools_4.0.5             
 [58] cli_3.6.1                generics_0.1.3           broom_1.0.4             
 [61] evaluate_0.17            fastmap_1.1.0            ragg_1.2.2              
 [64] knitr_1.42               zip_2.2.2                rootSolve_1.8.2.3       
 [67] nlme_3.1-152             quantreg_5.94            slam_0.1-50             
 [70] RConics_1.1.1            ROI_1.0-1                xml2_1.3.3              
 [73] compiler_4.0.5           rstudioapi_0.14          png_0.1-7               
 [76] e1071_1.7-12             ggsignif_0.6.4           lpSolveAPI_5.5.2.0-17.9 
 [79] stringi_1.7.8            vctrs_0.6.4              ROI.plugin.lpsolve_1.0-2
 [82] pillar_1.9.0             lifecycle_1.0.3          data.table_1.14.4       
 [85] cowplot_1.1.1            lmom_2.9                 R6_2.5.1                
 [88] latticeExtra_0.6-30      gridExtra_2.3            gld_2.6.6               
 [91] codetools_0.2-18         polspline_1.1.20         boot_1.3-27             
 [94] withr_2.5.0              multcomp_1.4-20          mgcv_1.8-34             
 [97] expm_0.999-6             hms_1.1.2                grid_4.0.5              
[100] rpart_4.1-15             class_7.3-18             rmarkdown_2.17          
[103] carData_3.0-5            numDeriv_2016.8-1.1      base64enc_0.1-3         
[106] interp_1.1-3

#####################################################################################