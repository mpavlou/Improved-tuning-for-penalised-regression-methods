# Code for Main simulation study (comparison of methods)

# Code produces Figures 3-4 and S1-S7 and intermediate data

############################################################################################

# Set working directory

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


# Create folders 'intermediate_results' and 'figures_tables'

dir.create(file.path("intermediate_results"), recursive = FALSE)
dir.create(file.path("figures_tables"), recursive = FALSE)

############################################################################################

# Important: Parameters to be changed for a quick run and testing the code

# Number of simulations (nsim)
# Number of bootstrap samples (bn) and
# Size of validation data (Nval)

nsim  <- 1000
bn    <- 100
Nval  <- 50000

# For code testing un-comment the below (smaller number of simulations,
# bootstrap samples and size of validation data

# nsim  <- 50
# bn    <- 20
# Nval  <- 10000

# ##########################################################################################

# Load required packages (and install if not installed already)

load.lib <-c("MASS", "doParallel", "parallel", "glmnet","rms", "speedglm", "tidyverse",
             "patchwork","logistf","pmsampsize","plyr","pROC","blorr","DescTools",
             "ggpubr","predtools", "RcppNumerical", "brglm2", "detectseparation","brglm2")

# Select only the packages that aren't currently installed.

install.lib <- load.lib[!load.lib %in% installed.packages()]

# Install the missing packages, including their dependencies
for (lib in install.lib) install.packages(lib,dependencies=TRUE)

# After the installation process completes, we load all packages.
sapply(load.lib,require,character=TRUE)

# Register cores for parallel computing

cores <- parallel::detectCores()
cl    <- parallel::makeCluster(cores[1]-1)
registerDoParallel(cl)

# ##########################################################################################

# Load require functions

source("paper_functions.R")

############################

# Inputs for the simulation scenarios (prevalence=0.1 or 0.5)

# The 'base' beta=(0.5, 0.3, 0.3, 0.25, 0.25, 0,0,0,0,0,0,0)
# and strength below corresponds to the multiplier to
# achieve the required C-statistic
# beta0 corresponds to the intercept term for the required
# outcome prevalence
# Consider:
# 2 outcome prevalences (0.1, 0.5),
# 2 model strengths (C=0.7, 0.8)
# 3 sample sizes for each combination of prevalence and model
# strength

###############################################################

# Parameters
n.true.predictors  <- 5
n.noise.predictors <- 7
n.predictors       <- n.true.predictors + n.noise.predictors


# Prevalence = 0.5
inputsp05c07      <- c(0, 0.93, 0.7035, 0.4992,  37.5)
inputsp05c08      <- c(0, 1.63, 0.8025, 0.5003,  21.25)

inputsp05         <- data.frame(rbind (inputsp05c07, inputsp05c08))
names(inputsp05)  <- c("beta.0", "strength", "c_true", "prev", "epv_req")

# Prevalence = 0.1

inputsp01c07     <- c(-2.4222, 0.89, 0.7015, 0.0993, 18.25)
inputsp01c08     <- c(-2.7839, 1.49, 0.8013, 0.1004, 9.375)

inputsp01        <- data.frame(rbind (inputsp01c07, inputsp01c08))
names(inputsp01) <- c("beta.0", "strength", "c_true", "prev", "epv_req")

#########################################################################

# Prevalence values 0.5 or 0.1

prev_values      <- c(0.5, 0.1)

###############################

for (prev in prev_values) {

if (prev==0.1) inputs <- inputsp01
if (prev==0.5) inputs <- inputsp05

k               <- 0
out_strength    <- NULL
strength_values <- inputs$strength
ctrue           <- round(inputs$c_true,2)


for (strength in strength_values) {

mle          <- matrix(nrow=nsim, ncol=11)
firth        <- matrix(nrow=nsim, ncol=11)
boot.shrink  <- matrix(nrow=nsim, ncol=11)
heur.shrink  <- matrix(nrow=nsim, ncol=11)
ridge        <- matrix(nrow=nsim, ncol=11)
boot.ridge   <- matrix(nrow=nsim, ncol=11)
boot.ridge1  <- matrix(nrow=nsim, ncol=11)
lasso        <- matrix(nrow=nsim, ncol=11)
boot.lasso   <- matrix(nrow=nsim, ncol=11)
boot.lasso1  <- matrix(nrow=nsim, ncol=11)

k <- k+1

# Consider 4 sample sizes 5N/4, N, 3*N/4, N/2, where N is the recommended size

epv   <- sort( c(round(inputs$epv_req[k],1)/2, round(inputs$epv_req[k],1)*3/4,
                 round(inputs$epv_req[k],1), round(inputs$epv_req[k],1)*5/4  ))

N     <- ceiling(epv*(n.predictors)/prev)

#########################################################################


# Run the simulation

out_epv<-NULL

for(j in 1: length(epv) ){

  cat("\n loop = ", c(strength,epv[j]),"\n")

  set.seed(101)

  beta.true <- c(inputs$beta.0[k],0.5, 0.3, 0.3, 0.25, 0.25, rep(0, n.noise.predictors))*strength

  source("sim_2_methods.R")

    out_epv     <- rbind(out_epv,all_methods)

}

  out_strength <- rbind(out_strength,out_epv)

}

out_p <-data.frame(out_strength)

names(out_p)=c("prev","strength","c_true", "epv","method", "lambda", "slope", "c_est", "brier", "rmse", "sep")

 if (prev==0.1) save.image("intermediate_results/penalised_p_01.Rdata")
 if (prev==0.5) save.image("intermediate_results/penalised_p_05.Rdata")

}

parallel::stopCluster(cl)

# Save with smaller size

load("intermediate_results/penalised_p_01.Rdata")
rm(list=setdiff(ls(), c("out_p", "inputs", "n.predictors", "prev")))
save.image("intermediate_results/penalised_p_01.Rdata")

load("intermediate_results/penalised_p_05.Rdata")
rm(list=setdiff(ls(), c("out_p", "inputs", "n.predictors", "prev")))
save.image("intermediate_results/penalised_p_05.Rdata")

#######################################################################################################

#Plots

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

source("sim_2_plots.R")

#######################################################################################################





