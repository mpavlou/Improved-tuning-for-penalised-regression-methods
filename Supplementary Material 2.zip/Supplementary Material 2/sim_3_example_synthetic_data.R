# Code for Synthetic data analysis (based on real data)

# Produces Figures S9, S10

############################################################################

# Set working directory

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Create folders 'intermediate_results' and 'figures_tables'

dir.create(file.path("intermediate_results"), recursive = FALSE)
dir.create(file.path("figures_tables"), recursive = FALSE)

############################################################################


# Important: Parameters to be changed for a quick run and code testing

# Number of simulations (nsim)
# Number of bootstrap samples (bn) and

nsim  <- 200
bn    <- 100


# For code testing un-comment the below (smaller nsim and bn)

# nsim  <- 50
# bn    <- 20

############################################################################

# Load required packages (install if not installed already)

load.lib <-c("MASS", "doParallel", "parallel", "glmnet","rms", "speedglm",
             "tidyverse","patchwork","logistf","pmsampsize","plyr","pROC",
             "blorr","DescTools", "ggpubr","predtools", "RcppNumerical",
             "brglm2", "detectseparation","brglm2", "vtable")

install.lib <- load.lib[!load.lib %in% installed.packages()]

# And finally we install the missing packages, including their dependency.
for (lib in install.lib) install.packages(lib,dependencies=TRUE)

# After the installation process completes, we load all packages.
sapply(load.lib,require,character=TRUE)

############################################################################

# Register cores for parallel computing

cores <- parallel::detectCores()
cl    <- parallel::makeCluster(cores[1]-1)
registerDoParallel(cl)

############################################################################

# Load require functions

source("paper_functions.R")


# Simulation based on the real data

# First create synthetic data with features similar to the real data

epv  <- 0
Ntot <- 50000


# Vector of coefficients from real data
beta.true <- c(-5.2,  1.17*c(0.02835,  0.24283,  0.09113,  1.01,  0.47829, -0.02279,  0.21326,  0.67647,  0.30326,  0.72054,  0.66004))

set.seed(2022)

# Contunuous
age1     <- rnorm(Ntot, 64.4, 12.2)
age      <-age1
zbmi1    <- rnorm(Ntot, 25.3, 4.9)
zbmi     <- zbmi1
age[age<quantile(age1,0.01)]    <-quantile(age1,0.01)
age[age>quantile(age1,0.99)]    <-  quantile(age1,0.99)
zbmi[zbmi<quantile(zbmi1,0.01)] <- quantile(zbmi1,0.01)
zbmi[zbmi>quantile(zbmi1,0.99)] <- quantile(zbmi1,0.99)

# Binary
sex    <- rbinom(Ntot, 1, 0.417)
zresp  <- rbinom(Ntot, 1, 0.078)
zrenal <- rbinom(Ntot, 1, 0.052)
zarrhy <- rbinom(Ntot, 1, 0.347)

zhyper <- rbinom(Ntot, 1, 0.310)
zeject <- rbinom(Ntot, 1, 0.071)
zdiab  <- rbinom(Ntot, 1, 0.078)
zprior <- rbinom(Ntot, 1, 0.291)
seq    <- rbinom(Ntot, 1, 0.141)

xwhole  <- cbind(age, sex, zresp, zrenal, zarrhy, zbmi, zhyper, zeject, zdiab, zprior, seq)
lpwhole <- cbind(1,xwhole)%*%beta.true
ywhole  <- rbinom(Ntot,1, invlogit(lpwhole) )

mean(ywhole)
mydata <- data.frame(xwhole, ywhole)
whole  <- cbind(ywhole, xwhole)

names(mydata) = c("age", "sex", "zresp", "zrenal", "zarrhy",  "zbmi",   "zhyper",  "zeject", "zdiab",  "zprior", "seq", "status")

mleres       <- NULL
ridgeres     <- NULL
bootridgeres <- NULL
modridgeres  <- NULL


Nrec = 2200

N <- Nrec

for (N in c(round(3*Nrec/4), Nrec, round(5*Nrec/4))){
  
  cat("\n size = ", c(N),"\n")
  
  epv <- round(N *mean(mydata$status)/(ncol(xwhole)-1),1)
  
  i<-1
  
  for (i in 1:nsim){

    set.seed(i+200)
    
    #split into training and test sets

    sample <- N/Ntot
    
    #separate training and test sets
    
    train    <- sample(Ntot, N)
    trainset <- whole[train,]
    testset  <- whole[-train,]
    
    # Development matrices
    
    x    <- as.matrix(trainset[,-1])
    x    <- cbind(1,x[,])
    y    <- trainset[, 1]
    
    # Validation matrices
    
    yval <- testset[,1 ]
    xval <- as.matrix(testset[,-1])
    xval <- cbind(1,xval[,])
    
    # Detect separation
    
    sep      <- ifelse(glm(y~x, family="binomial", method = "detect_separation", purpose="test",
                          linear_program = "dual")$outcome==T, 1, 0)
    
    # MLE
    fit      <-  glm.fit(x,y, family = binomial())
    beta     <-  as.vector(coef(fit))
    mle      <-  c(0,epv, measures_example(yval, xval, beta),1,N,as.vector(beta), sep)
    
    
    # Classical Ridge
    set.seed(i)
    a       <- cv.glmnet(x[,-1],y,type.measure="deviance",family="binomial",alpha=0, nfolds=10,
                         standardize=TRUE, parallel = TRUE)
    beta   <- as.vector(coef(a,s="lambda.min") )
    lambda <- a$lambda.min;
    ridge  <-  c(1, epv, measures_example(yval, xval, beta),lambda,N,as.vector(beta), sep)
    
    # Boot ridge
    set.seed(i)
    a               <-  boot_penal_foreach(x=x[,-1], y=y, method="ridge", bn=bn)
    lambda          <-  a$lambda.boot
    beta            <-  a$beta.boot
    boot.ridge      <-  c(2, epv, measures_example(yval, xval, beta),lambda, N, as.vector(beta), sep)
    
    # Mod ridge
    set.seed(i)
    a               <-  mod_penal_ave_foreach(x=x[,-1], y=y, method="ridge", bn=bn)
    lambda          <-  a$lambda.boot
    beta            <-  a$beta.boot
    mod.ridge       <-  c(3, epv, measures_example(yval, xval, beta), lambda, N,as.vector(beta), sep)
    
    
    mleres          <- rbind(mleres, mle)
    ridgeres        <- rbind(ridgeres, ridge)
    bootridgeres    <- rbind(bootridgeres, boot.ridge)
    modridgeres     <- rbind(modridgeres, mod.ridge)
    
  }
}

res <- rbind(mleres, ridgeres, bootridgeres, modridgeres)

res        <- data.frame(res)
res        <- res[,c(1:7,20)]
names(res) <- c("method","epv", "cs", "cstat", "brier", "lambda","N", "sep")

# Save with smaller size

rm(list=setdiff(ls(), c("res")))

save.image("intermediate_results/example_synthetic.Rdata")

####################################################################################################

#Plots

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

source("sim_3_example_synthetic_data_plots.R")

#######################################################################################################

