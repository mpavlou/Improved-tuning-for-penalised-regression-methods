# Code for Main simulation study (effect of cross-validation folds)

# Produces Figures 1-2 and intermediate data

# ##########################################################################################

# Set working directory

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Create folders 'intermediate_results' and 'figures_tables'

dir.create(file.path("intermediate_results"), recursive = FALSE)
dir.create(file.path("figures_tables"), recursive = FALSE)

# ##########################################################################################

# Important: Parameters to be changed for a quick run and testing the code

# Number of simulations (nsim)
# Number of bootstrap samples (bn) and
# Size of validation data (Nval)

nsim <- 1000
bn   <- 100
Nval <- 50000

# For code testing un-comment the below 3 lines (smaller number of simulations,
# bootstrap samples and size of validation data

# nsim <- 50
# bn   <- 20
# Nval <- 10000

# ##########################################################################################


# Load required packages (install if not installed already)

load.lib <-c("MASS", "doParallel", "parallel", "glmnet","rms", "speedglm", "tidyverse",
             "patchwork","logistf","pmsampsize","plyr","pROC","blorr","DescTools",
             "ggpubr","predtools", "RcppNumerical", "brglm2", "detectseparation")

# Then we select only the packages that aren't currently installed.

install.lib <- load.lib[!load.lib %in% installed.packages()]

# And finally we install the missing packages, including their dependency.
for (lib in install.lib) install.packages(lib,dependencies=TRUE)

# After the installation process completes, we load all packages.
sapply(load.lib,require,character=TRUE)

# Register cores for parallel computing

cores <- parallel::detectCores()
cl    <- parallel::makeCluster(cores[1]-1)
registerDoParallel(cl)

#########################################################

# Load required functions

source("paper_functions.R")

#########################################################

# Inputs for the simulation scenarios (prevalence=0.1 or 0.5)

# The 'base beta=(0.5, 0.3, 0.3, 0.25, 0.25, 0,0,0,0,0,0,0)
# and strength below corresponds to the multiplier to
# achieve the required C-statistic

# Parameters
n.true.predictors  <- 5
n.noise.predictors <- 7
n.predictors       <- n.true.predictors + n.noise.predictors


# Prevalence = 0.5
inputsp05c07      <- c(0, 0.93, 0.7035, 0.4992,  37.5)
inputsp05c08      <- c(0, 1.63, 0.8025, 0.5003,  21.25)

inputsp05         <- data.frame(rbind (inputsp05c07, inputsp05c08))
names(inputsp05)  <- c("beta.0", "strength", "c_true", "prev", "epv_req")

prev <- 0.5

inputs          <- inputsp05
strength_values <- inputs$strength
ctrue           <- round(inputs$c_true,2)

#########################################################################

out_strength <- NULL
k            <- 0

for (strength in strength_values[1]) {

k<-k+1

epv   <- sort( c(round(inputs$epv_req[k],1)/2, round(inputs$epv_req[k],1)*3/4,
                 round(inputs$epv_req[k],1), round(inputs$epv_req[k],1)*5/4  ))

N     <- ceiling(epv*(n.predictors)/prev)

########################################################################

out_epv<-NULL

for(j in 1: length(epv) ){

  cat("\n loop = ", c(strength,epv[j]),"\n")

  set.seed(101)

  beta.true <- c(inputs$beta.0[k],0.5, 0.3, 0.3, 0.25, 0.25, rep(0, n.noise.predictors))*strength

  source("sim_1_methods.R")

  out_epv     <- rbind(out_epv,all_methods)

}

  out_strength <- rbind(out_strength,out_epv)

}


parallel::stopCluster(cl)

out_p <-data.frame(out_strength)

names(out_p)=c("prev","strength","c_true", "epv","method", "lambda", "slope", "c_est", "brier","mape")


# Save with smaller size

rm(list=setdiff(ls(), c("out_p", "inputs", "n.predictors", "prev")))

save.image("intermediate_results/penalised_p05_kfold_10F.Rdata")


#######################################################################################################

#Plots

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

source("sim_1_plots.R")

#######################################################################################################




